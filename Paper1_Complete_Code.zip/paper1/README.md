# Paper 1: low-light enhancement and detection

The remaining execution dependency is the actual server: local datasets, published detector/enhancer checkpoints, compatible existing Python packages and a GPU allocation must be qualified there. This repository contains the study planner, preparation, controlled training, evaluation and analysis code. It contains no measured paper results and has not been GPU-qualified on your server. Scripts install and download nothing.

Open the repository root in VS Code Remote SSH. Activate the environment already configured on your cluster and use a filesystem dataset path, such as `/nfs/nas/samiran1/Sajjan/Dataset`. Edit [configs/project.json](configs/project.json) once to supply actual image/annotation paths, detector checkpoints and enhancer source/checkpoint locations. Every path in that example is a user-editable placeholder. No source repository or checkpoint is bundled. The small [configs/pilot.json](configs/pilot.json) remains a standalone one-epoch engineering configuration.

```bash
export PYTHONPATH="$PWD/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
python -m lowlight_p1 --help
bash paper1/scripts/workflow.sh doctor --config paper1/configs/project.json
bash paper1/scripts/workflow.sh plan --config paper1/configs/project.json \
  --profile pilot --output /absolute/work/pilot.csv
```

Native data preparation is available through `prepare`; see [data layout](docs/data_layout.md). Canonical COCO input can be used directly. Preserve the official test split, derive development data from training, and freeze preparation records before training. A path placeholder is not evidence that your private archive matches an expected format.

Submit the pilot with site-specific resources, first inspecting the command:

```bash
bash paper1/scripts/workflow.sh submit --manifest /absolute/work/pilot.csv \
  --config paper1/configs/project.json --output-root /absolute/work \
  --partition YOUR_PARTITION --account YOUR_ACCOUNT \
  --gpus 1 --cpus 8 --memory 32G --time 12:00:00 \
  --max-concurrent 1 --dry-run
```

Remove `--dry-run` to submit. Omit partition/account to use actual scheduler defaults. The resource values are examples, not measured requirements. Time and memory must be chosen after a single allocated pilot. The default array stage trains only. Test evaluation is a separate explicit step; training must not select checkpoints on test AP.

```bash
bash paper1/scripts/workflow.sh status --config paper1/configs/project.json \
  --manifest /absolute/work/pilot.csv
# Run this inside a GPU allocation after training completes:
bash paper1/scripts/workflow.sh evaluate --config paper1/configs/project.json \
  --manifest /absolute/work/pilot.csv --split dev
```

`study-evaluate` evaluates the required raw/enhanced views for each manifest cell. Use `--split test` only after freezing model and recipe choices. Keep checkpoints and cached inference outputs so identical P2 predictions can be reused in contrasts and diagnostics. Analysis commands and scientific definitions follow [the audited specification](docs/AUDITED_SPEC_REFERENCE.md); use `python -m lowlight_p1 analyze --help` for the analysis input contract.

The full profile plans the 453 unique default-schedule trainings. Pilot matching cells are reusable only when provenance and every scientific setting match. Before broadening, require a reproducible data/capacity interaction or discriminating perturbation after input, order and optimization controls. The declared equivalence margin is 0.5 AP50 percentage points; non-significance does not establish equivalence.

```bash
bash paper1/scripts/workflow.sh plan --config paper1/configs/project.json \
  --profile full --output /absolute/work/full.csv
```

The full manifest is a schedule, not a claim that external weights, annotations or hardware passed qualification. Freeze it and its generated run configs. Resume only the unchanged run identity. See [SLURM operations](docs/slurm.md) for activation, retries, logs and separate inference stages.

Local dependency-free and available-runtime checks install nothing:

```bash
PYTHONPATH=paper1/src python -m unittest discover -s paper1/tests -v
bash paper1/tests/test_slurm.sh
```

The test suite distinguishes missing-runtime skips from executed checks. Mocked scheduler checks verify argument forwarding and dry-run behavior; they do not validate GPU training or scientific metric agreement. Record actual package versions, checkpoint hashes, dataset hashes, allocation timing and memory before reporting results.

For stored-prediction comparisons, feature extraction, source-only P0, final refit and extra inference controls, see [analysis and final evaluation](docs/analysis.md). The templates [analysis.example.json](configs/analysis.example.json) and [p0.example.json](configs/p0.example.json) require actual artifact paths and verified mappings before use.
