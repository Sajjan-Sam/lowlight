"""Paired cluster inference. Resamples recompute dataset metrics, never image AP."""
import copy
import numpy as np


def resample_coco(gt, predictions, sampled_image_ids):
    """Duplicate each drawn image AND its annotations/detections with fresh IDs."""
    images = {x['id']: x for x in gt['images']}
    out = {k: copy.deepcopy(v) for k, v in gt.items() if k not in ('images', 'annotations')}
    out.update(images=[], annotations=[])
    results = []
    anns = {}
    dets = {}
    for a in gt['annotations']: anns.setdefault(a['image_id'], []).append(a)
    for p in predictions: dets.setdefault(p['image_id'], []).append(p)
    for new_id, old_id in enumerate(sampled_image_ids, 1):
        im = copy.deepcopy(images[old_id]); im['id'] = new_id; out['images'].append(im)
        for a in anns.get(old_id, []):
            a = copy.deepcopy(a); a.update(id=len(out['annotations'])+1, image_id=new_id); out['annotations'].append(a)
        for p in dets.get(old_id, []):
            p = copy.deepcopy(p); p['image_id'] = new_id; results.append(p)
    return out, results


def cluster_groups(gt, cluster_key=None):
    groups = {}
    for im in gt['images']:
        if cluster_key and cluster_key not in im:
            raise ValueError(f'Missing cluster metadata {cluster_key} for image {im["id"]}')
        key = im[cluster_key] if cluster_key else im['id']
        groups.setdefault(key, []).append(im['id'])
    if not groups: raise ValueError('Nonempty image population required')
    return list(groups.values())


def paired_bootstrap(gt, baseline_seeds, treatment_seeds, metric, n_boot=1000, seed=0, cluster_key=None):
    """Conditional on supplied trained seeds; average seed metrics, not predictions.

    Same cluster draws and paired seed ordering are used in both conditions.
    CI captures held-out sampling variation, not training-seed uncertainty.
    """
    if not baseline_seeds or len(baseline_seeds) != len(treatment_seeds):
        raise ValueError('Nonempty paired seed prediction lists required')
    if n_boot < 2: raise ValueError('n_boot must be at least 2')
    groups = cluster_groups(gt, cluster_key); rng = np.random.default_rng(seed)
    def difference(ids):
        differences = []
        for a, b in zip(baseline_seeds, treatment_seeds):
            g, pa = resample_coco(gt, a, ids); _, pb = resample_coco(gt, b, ids)
            va,vb=metric(g,pa),metric(g,pb)
            if va is None or vb is None or not np.isfinite([va,vb]).all(): raise ValueError('Undefined endpoint for sampled population')
            differences.append(vb-va)
        return float(np.mean(differences))
    estimate = difference([i['id'] for i in gt['images']])
    draws = np.array([difference([i for j in rng.integers(len(groups), size=len(groups)) for i in groups[j]]) for _ in range(n_boot)])
    if not np.isfinite(draws).all(): raise ValueError('Undefined metric in bootstrap draw; choose valid endpoint/population')
    return {'difference': estimate, 'ci_low': float(np.quantile(draws, .025)), 'ci_high': float(np.quantile(draws, .975)), 'draws': draws.tolist(), 'n_clusters': len(groups), 'n_seeds': len(baseline_seeds), 'uncertainty': 'conditional_on_trained_seeds'}


def paired_permutation(gt, baseline_seeds, treatment_seeds, metric, n_perm=999, seed=0, cluster_key=None):
    """Randomize condition labels within paired clusters under exchangeability null."""
    if n_perm < 1 or not baseline_seeds or len(baseline_seeds) != len(treatment_seeds): raise ValueError('Positive permutations and paired seeds required')
    groups = cluster_groups(gt, cluster_key); rng = np.random.default_rng(seed)
    def value(aa, bb):
        values=[]
        for a,b in zip(aa,bb):
            va,vb=metric(gt,a),metric(gt,b)
            if va is None or vb is None or not np.isfinite([va,vb]).all(): raise ValueError('Undefined permutation endpoint')
            values.append(vb-va)
        return float(np.mean(values))
    observed = value(baseline_seeds,treatment_seeds); null=[]
    for _ in range(n_perm):
        swap={i for g,s in zip(groups,rng.integers(2,size=len(groups))) if s for i in g}
        aa=[]; bb=[]
        for a,b in zip(baseline_seeds,treatment_seeds):
            aa.append([p for p in a if p['image_id'] not in swap]+[p for p in b if p['image_id'] in swap])
            bb.append([p for p in b if p['image_id'] not in swap]+[p for p in a if p['image_id'] in swap])
        null.append(value(aa,bb))
    return {'difference': observed, 'p_value': float((1+sum(abs(x)>=abs(observed)-1e-12 for x in null))/(n_perm+1)), 'n_permutations':n_perm, 'null':'within_cluster_condition_exchangeability'}


def holm(p_values):
    p=np.asarray(p_values,dtype=float)
    if p.ndim!=1 or not np.isfinite(p).all() or ((p<0)|(p>1)).any(): raise ValueError('Finite p-values in [0,1] required')
    order=np.argsort(p); result=np.empty_like(p); running=0.
    for rank,index in enumerate(order):
        running=max(running,(len(p)-rank)*p[index]); result[index]=min(1.,running)
    return result.tolist()
