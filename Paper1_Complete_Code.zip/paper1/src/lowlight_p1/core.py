"""Auditable configuration, atomic run state and canonical COCO inputs."""
import contextlib, hashlib, json, os, random, time
from pathlib import Path

def sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def atomic_json(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.{os.getpid()}.tmp')
    with open(tmp,'w') as f: json.dump(value,f,indent=2,allow_nan=False); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)

def read_config(path):
    with open(path) as f:
        if str(path).endswith(('.yaml','.yml')):
            import yaml
            c=yaml.safe_load(f)
        else: c=json.load(f)
    c.setdefault('output_root','/nfs/nas/samiran1/Sajjan/lowlight_paper1_runs')
    c.setdefault('seed',0); c.setdefault('run_id','pilot'); c.setdefault('protocol','standard')
    return c

def seed_all(seed):
    import numpy as np, torch
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True

@contextlib.contextmanager
def run_lock(directory):
    import fcntl
    directory=Path(directory); directory.mkdir(parents=True,exist_ok=True)
    with open(directory/'.lock','a') as f:
        try: fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError(f'Run already active: {directory}')
        yield directory

def load_coco(spec,check_files=True):
    from PIL import Image
    p=Path(spec['annotations']); c=json.loads(p.read_text())
    imgs=c.get('images',[]); cats=c.get('categories',[]); anns=c.get('annotations',[])
    if not imgs or not cats: raise ValueError(f'Empty images/categories: {p}')
    ids=[i['id'] for i in imgs]; cid=[i['id'] for i in cats]
    if len(set(ids))!=len(ids) or len(set(cid))!=len(cid): raise ValueError('Duplicate image/category IDs')
    byid={i['id']:i for i in imgs}; catset=set(cid); seen=set(); names=set()
    for i in imgs:
        name=i['file_name']
        if name in names: raise ValueError('Duplicate filenames')
        names.add(name)
        root=Path(spec['image_root']).resolve(); ip=(root/name).resolve()
        if not ip.is_relative_to(root): raise ValueError('Image path escapes image_root')
        if min(i['width'],i['height'])<=0: raise ValueError('Invalid dimensions')
        if check_files:
            with Image.open(ip) as im:
                if im.size!=(i['width'],i['height']): raise ValueError(f'Dimension mismatch: {ip}')
                if im.getexif().get(274,1)!=1: raise ValueError(f'EXIF orientation requires explicit box conversion: {ip}')
    for a in anns:
        if a['id'] in seen: raise ValueError('Duplicate annotation ID')
        seen.add(a['id'])
        if a['image_id'] not in byid or a['category_id'] not in catset: raise ValueError('Unknown annotation image/category')
        import math
        x,y,w,h=a['bbox']; im=byid[a['image_id']]
        if not all(math.isfinite(v) for v in (x,y,w,h)) or min(x,y)<0 or min(w,h)<=0 or x+w>im['width']+1e-5 or y+h>im['height']+1e-5: raise ValueError(f'Invalid box: {a}')
    return c

def validate_data(config):
    result={}; partitions={}; category_order=None
    for split,spec in config['data'].items():
        c=load_coco(spec); order=sorted((x['id'],x['name']) for x in c['categories'])
        if category_order is not None and order!=category_order: raise ValueError('Class mapping differs across splits')
        category_order=order
        hashes={sha256(Path(spec['image_root'])/i['file_name']) for i in c['images']}
        for other,old in partitions.items():
            if hashes & old and not (config.get('final_refit',False) and {split,other}=={'train','dev'}): raise ValueError(f'Byte-identical image leakage: {split}/{other}')
        partitions[split]=hashes
        result[split]={'images':len(c['images']),'objects':len(c['annotations']),'annotation_sha256':sha256(spec['annotations']),'image_hashes':sorted(hashes)}
    if not {'train','dev','test'}<=set(result): raise ValueError('Explicit disjoint train/dev/test required')
    if config.get('final_refit',False) and not partitions['dev']<=partitions['train']: raise ValueError('final_refit requires the complete development pool within training')
    return result
