"""Strict native annotation conversion; no source images or labels are modified."""
import collections
import json
from pathlib import Path
import random
import xml.etree.ElementTree as ET
from PIL import Image
from .core import atomic_json, load_coco, sha256, validate_data

EXDARK_CLASSES = ('Bicycle','Boat','Bottle','Bus','Car','Cat','Chair','Cup','Dog','Motorbike','People','Table')

def _inside(root, name):
    name = str(name)
    if Path(name).is_absolute() or '..' in Path(name).parts:
        raise ValueError(f'Unsafe relative path: {name}')
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError(f'Path escapes root: {name}')
    return path

def _index(root):
    result = collections.defaultdict(list)
    for p in sorted(root.rglob('*')):
        if p.is_file() and p.suffix.lower() in {'.jpg','.jpeg','.png','.bmp','.tif','.tiff'}:
            _inside(root, p.relative_to(root))
            result[p.name].append(p.relative_to(root).as_posix())
    return result

def _resolve(root, index, name):
    path = _inside(root, name)
    if path.is_file(): return path.relative_to(root.resolve()).as_posix()
    matches = index.get(Path(name).name, [])
    if len(matches) != 1: raise ValueError(f'Missing or ambiguous image: {name}: {matches}')
    return matches[0]

def _lines(path):
    return [s.strip() for s in Path(path).read_text().splitlines() if s.strip() and not s.lstrip().startswith('#')]

def _partition(records, fraction, seed):
    """Greedy iterative multilabel stratification, with a seeded tie order."""
    if not 0 < fraction < 1 or len(records) < 2:
        raise ValueError('Need at least two training images and dev_fraction in (0,1)')
    n = max(1, min(len(records)-1, round(len(records)*fraction)))
    rng = random.Random(seed)
    order = list(range(len(records))); rng.shuffle(order)
    rank = {j:i for i,j in enumerate(order)}
    labels = [set(a[0] for a in r['boxes']) for r in records]
    counts = collections.Counter(c for ls in labels for c in ls)
    desired = {c: v*fraction for c,v in counts.items()}
    selected = []; remaining = set(order)
    for _ in range(n):
        positive = {c:d for c,d in desired.items() if d > 0 and any(c in labels[j] for j in remaining)}
        rare = min(positive, key=lambda c:(counts[c], str(c))) if positive else None
        candidates = [j for j in remaining if rare is None or rare in labels[j]]
        j = max(candidates, key=lambda j:(sum(max(0,desired[c])/counts[c] for c in labels[j]), -rank[j]))
        selected.append(j); remaining.remove(j)
        for c in labels[j]: desired[c] -= 1
    return [records[j] for j in sorted(remaining)], [records[j] for j in sorted(selected)]

def prepare(config):
    """Convert one dataset. See docs/data_layout.md for explicit native input keys."""
    c = dict(config); kind = c['dataset'].lower()
    if kind not in {'exdark','maet','darkface','nod'}: raise ValueError(f'Unsupported dataset: {kind}')
    expected = {'exdark':'xywh_1based','maet':'xyxy_1based_inclusive','darkface':'xyxy_0based_inclusive','nod':'coco_xywh_0based'}[kind]
    if c.get('bbox_convention',expected) != expected: raise ValueError(f'Expected bbox_convention={expected}')
    root = Path(c['image_root']).resolve()
    annroot = Path(c.get('annotation_root',root)).resolve()
    out = Path(c.get('output_root','/nfs/nas/samiran1/Sajjan/lowlight_paper1_runs/prepared')).resolve()/kind
    if out.is_relative_to(root) or out.is_relative_to(annroot): raise ValueError('Output must be outside input roots')
    if not root.is_dir() or not annroot.is_dir(): raise ValueError('Input image/annotation roots must exist')
    index = _index(root); inputs = {}; metadata = {'bbox_convention':expected}; records = {}; categories = []
    def track(p):
        p = Path(p); inputs[str(p.resolve())] = sha256(p); return p
    def record(name, split, boxes, **extra):
        name = _resolve(root,index,name)
        if name in records: raise ValueError(f'Duplicate/overlapping split image: {name}')
        with Image.open(_inside(root,name)) as im:
            if im.getexif().get(274,1) != 1: raise ValueError(f'EXIF orientation requires explicit conversion: {name}')
            w,h = im.size
        records[name] = dict(file_name=name,width=w,height=h,split=split,boxes=boxes,**extra)
    if kind == 'nod':
        catref = None
        for split in ('train','test'):
            path = track(c[split+'_annotations'])
            coco = load_coco({'annotations':str(path),'image_root':str(root)})
            cats = sorted(coco['categories'],key=lambda x:x['id'])
            if catref is not None and cats != catref: raise ValueError('NOD category mapping differs')
            catref = cats; categories = cats
            anns = collections.defaultdict(list)
            for a in coco['annotations']: anns[a['image_id']].append((a['category_id'],a['bbox'],a.get('iscrowd',0)))
            for im in coco['images']:
                record(im['file_name'],split,anns[im['id']],source_image_id=im['id'],**{k:v for k,v in im.items() if k not in {'id','file_name','width','height'}})
    elif kind == 'exdark':
        categories = [dict(id=i+1,name=name) for i,name in enumerate(EXDARK_CLASSES)]
        classids = {v['name'].lower():v['id'] for v in categories}
        for line in _lines(track(c['class_list'])):
            fields = line.split()
            if [v.lower() for v in fields] in (['name','class','lighting','type'], ['name','class','lighting','split']): continue
            if len(fields) != 4: raise ValueError('ExDark class list needs filename class lighting split')
            name, cls, lighting, split = fields
            if split not in {'1','2','3'}: raise ValueError(f'Unknown ExDark split: {split}')
            if not cls.isdigit() or not 1 <= int(cls) <= 12: raise ValueError(f'Invalid ExDark class: {cls}')
            resolved = _resolve(root,index,name)
            label = _inside(annroot,resolved+'.txt')
            if not label.exists():
                candidates = list(annroot.rglob(Path(name).name+'.txt'))
                if len(candidates)!=1: raise ValueError(f'Missing/ambiguous bbGt: {name}')
                label = candidates[0]; _inside(annroot,label.relative_to(annroot))
            lines = _lines(track(label)); boxes = []
            if not lines or not lines[0].startswith('% bbGt'): raise ValueError(f'Missing bbGt header: {label}')
            for row in lines[1:]:
                f = row.split()
                if len(f)<5 or f[0].lower() not in classids: raise ValueError(f'Invalid bbGt object: {row}')
                x,y,w,h = map(float,f[1:5]); boxes.append((classids[f[0].lower()],[x-1,y-1,w,h],0))
            record(name,'test' if split=='3' else 'train',boxes,lighting=lighting,source_class=int(cls),official_split=split)
        metadata['bbox_convention'] = '1-based xywh; subtract 1 from x,y only'
    else:
        categories = [dict(id=1,name='face')] if kind=='darkface' else []
        classnames = set(); pending = []
        for split in ('train','test'):
            for row in _lines(track(c[split+'_list'])):
                if len(row.split()) != 1: raise ValueError('Split lists require one relative filename/image ID per line')
                name = row
                if not Path(name).suffix:
                    matches = [v for values in index.values() for v in values if Path(v).stem==name]
                    if len(matches)!=1: raise ValueError(f'Missing/ambiguous image ID: {name}')
                    name = matches[0]
                resolved = _resolve(root,index,name)
                labelname = str(Path(resolved).with_suffix('.xml' if kind=='maet' else '.txt'))
                label = _inside(annroot,labelname)
                if not label.exists():
                    candidates = list(annroot.rglob(Path(labelname).name))
                    if len(candidates)!=1: raise ValueError(f'Missing/ambiguous label: {labelname}')
                    label = candidates[0]; _inside(annroot,label.relative_to(annroot))
                track(label); boxes = []
                if kind=='maet':
                    xml = ET.parse(label).getroot()
                    with Image.open(_inside(root,resolved)) as im:
                        if xml.findtext('size/width') is not None and (int(xml.findtext('size/width')),int(xml.findtext('size/height'))) != im.size: raise ValueError('VOC dimension mismatch')
                    for obj in xml.findall('object'):
                        cls = obj.findtext('name'); classnames.add(cls)
                        b = obj.find('bndbox'); x,y,x2,y2 = [float(b.findtext(k)) for k in ('xmin','ymin','xmax','ymax')]
                        
                        if x2 < x or y2 < y: raise ValueError('Reversed VOC box')
                        boxes.append((cls,[x-1,y-1,x2-x+1,y2-y+1],0))
                else:
                    lines = _lines(label)
                    try: count = int(lines[0])
                    except (IndexError,ValueError): raise ValueError('DarkFace label must start with object count')
                    if count<0 or len(lines)!=count+1: raise ValueError('DarkFace object count mismatch')
                    for row in lines[1:]:
                        f = row.split()
                        if len(f) not in (4,5): raise ValueError('DarkFace rows require x1 y1 x2 y2 [ignore]')
                        x,y,x2,y2 = map(float,f[:4])
                        if x2 < x or y2 < y: raise ValueError('Reversed DarkFace box')
                        if len(f)==5 and f[4] not in {'0','1'}: raise ValueError('Invalid ignore flag')
                        boxes.append((1,[x,y,x2-x+1,y2-y+1],int(f[4]) if len(f)==5 else 0))
                pending.append((resolved,split,boxes))
        if kind=='maet':
            categories = [dict(id=i+1,name=v) for i,v in enumerate(sorted(classnames))]
            ids = {v['name']:v['id'] for v in categories}
            pending = [(n,s,[(ids[k],b,z) for k,b,z in a]) for n,s,a in pending]
        for name,split,boxes in pending: record(name,split,boxes)
        metadata['bbox_convention'] = '1-based inclusive xyxy to 0-based xywh' if kind=='maet' else '0-based inclusive xyxy to xywh (+1 extent)'
    train = sorted((r for r in records.values() if r['split']=='train'),key=lambda r:r['file_name'])
    train,dev = _partition(train,float(c.get('dev_fraction',.1)),int(c.get('seed',0)))
    partitions = {'train':train,'dev':dev,'test':[r for r in records.values() if r['split']=='test']}
    specs = {}; imagehashes = {}; seen = {}
    for split, rows in partitions.items():
        if not rows: raise ValueError(f'Empty partition: {split}')
        images=[]; annotations=[]
        for i,r in enumerate(sorted(rows,key=lambda r:r['file_name']),1):
            digest=sha256(_inside(root,r['file_name']))
            if digest in seen and seen[digest]!=split: raise ValueError(f'Byte-identical image leakage: {split}/{seen[digest]}')
            seen[digest]=split; imagehashes[r['file_name']]=digest
            images.append(dict(id=i,**{k:v for k,v in r.items() if k not in {'boxes','split'}}))
            for cls,bbox,crowd in r['boxes']:
                annotations.append(dict(id=len(annotations)+1,image_id=i,category_id=cls,bbox=bbox,area=bbox[2]*bbox[3],iscrowd=crowd))
        path=out/(split+'.json'); payload=dict(images=images,annotations=annotations,categories=categories)
        # Validate before exposing final outputs, including finite/out-of-bounds boxes.
        out.mkdir(parents=True,exist_ok=True); atomic_json(path,payload)
        specs[split]=dict(annotations=str(path),image_root=str(root))
        load_coco(specs[split])
    validation=validate_data({'data':specs})
    # This overlapping union is intentionally outside the disjoint split map.
    all_images = []; all_annotations = []
    for i,r in enumerate(sorted(train+dev,key=lambda r:r['file_name']),1):
        all_images.append(dict(id=i,**{k:v for k,v in r.items() if k not in {'boxes','split'}}))
        for cls,bbox,crowd in r['boxes']:
            all_annotations.append(dict(id=len(all_annotations)+1,image_id=i,category_id=cls,bbox=bbox,area=bbox[2]*bbox[3],iscrowd=crowd))
    all_path = out/'train_all.json'
    atomic_json(all_path,dict(images=all_images,annotations=all_annotations,categories=categories))
    train_all = dict(annotations=str(all_path),image_root=str(root))
    load_coco(train_all)
    train_all_validation = dict(images=len(all_images),objects=len(all_annotations),annotation_sha256=sha256(all_path))
    manifest=dict(dataset=kind,input_roots=dict(image_root=str(root),annotation_root=str(annroot)),output_root=str(out),seed=int(c.get('seed',0)),dev_fraction=float(c.get('dev_fraction',.1)),split_method='seeded greedy iterative multilabel stratification from official training only',categories=categories,input_sha256=inputs,image_sha256=imagehashes,metadata=metadata,validation=validation,data=specs,train_all=train_all,train_all_validation=train_all_validation)
    atomic_json(out/'manifest.json',manifest)
    return dict(data=specs,train_all=train_all,manifest=str(out/'manifest.json'))
