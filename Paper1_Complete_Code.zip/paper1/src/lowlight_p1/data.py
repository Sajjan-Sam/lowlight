"""Shared, explicit detector geometry and finite augmentation banks."""
import hashlib, random, math
from pathlib import Path
from .core import load_coco

class Enhancer:
    def __init__(self, config):
        from .enhancers import create_enhancer
        self.config=dict(config); self.fn=create_enhancer(self.config.pop('name','identity'),self.config)
        self.provenance=self.fn.provenance
    def __call__(self,x):
        import torch
        from .enhancers import cached_enhance
        a=x.permute(1,2,0).cpu().numpy(); cache=self.config.get('cache_dir')
        y=cached_enhance(self.fn,a,cache) if cache else self.fn(a)
        return torch.from_numpy(y.copy()).permute(2,0,1).to(x.device)

def nested_order(images, annotations, seed, image_root=None):
    """Greedy deficit balancing of multilabel class, brightness and relative-size strata.

    One ordering is used at every fraction, guaranteeing exact nesting. Brightness
    is measured on training pixels only; evaluation metadata never enters selection.
    """
    from PIL import Image, ImageStat
    by={i['id']:[] for i in images}
    for a in annotations: by[a['image_id']].append(a)
    strata={}
    for i in images:
        keys={('class',a['category_id']) for a in by[i['id']]}
        keys|={('size',min(2,int(3*math.sqrt(a['bbox'][2]*a['bbox'][3]/(i['width']*i['height']))))) for a in by[i['id']]}
        if image_root:
            with Image.open(Path(image_root)/i['file_name']) as im: brightness=ImageStat.Stat(im.convert('L')).mean[0]/255
            keys.add(('brightness',min(3,int(brightness*4))))
        strata[i['id']]=keys or {('empty',0)}
    from collections import Counter
    totals=Counter(k for keys in strata.values() for k in keys)
    rng=random.Random(seed); remaining=list(strata); rng.shuffle(remaining); selected=[]; counts=dict.fromkeys(totals,0)
    while remaining:
        n=len(selected)+1
        chosen=max(remaining,key=lambda uid:sum((n*totals[k]/len(images)-counts[k])/totals[k] for k in strata[uid]))
        remaining.remove(chosen); selected.append(chosen)
        for k in strata[chosen]: counts[k]+=1
    return selected

class CocoDataset:
    def __init__(self,spec,config,training=False):
        self.coco=load_coco(spec); self.spec=spec; self.config=config; self.training=training; self.epoch=0
        self.images=sorted(self.coco['images'],key=lambda i:i['id']); self.categories=sorted(c['id'] for c in self.coco['categories'])
        self.label={c:i+1 for i,c in enumerate(self.categories)}; self.anns={i['id']:[] for i in self.images}
        for a in self.coco['annotations']: self.anns[a['image_id']].append(a)
        f=float(config.get('fraction',1))
        if not 0<f<=1: raise ValueError('fraction must be in (0,1]')
        self.full_count=len(self.images)
        if training and f<1:
            order=nested_order(self.images,self.coco['annotations'],config.get('subset_seed',config.get('seed',0)),spec['image_root'])
            selected=set(order[:max(1,int(len(order)*f))]); self.images=[i for i in self.images if i['id'] in selected]
            self.subset_order=order
        elif training:
            # Full-data membership is invariant to ranking; avoid the quadratic
            # balancing pass and pixel brightness reads for full-data jobs.
            self.subset_order=[i['id'] for i in self.images]
        mode=config.get('train_view' if training else 'test_view','raw')
        self.enhance=Enhancer(config.get('enhancer',{}) if mode!='raw' else {'name':'identity'})
        protocol=config.get('protocol','exact_six_view')
        self.gammas=(1.,.7,1.4)
        if config.get('experiment')=='order' or protocol=='order': self.gammas=(.8,1.,1.25)
        if config.get('augmentation_bank')=='strong': self.gammas=(1.,.7,1.4,.45,2.,None)
        self.noise_seeds={i['id']:int.from_bytes(hashlib.sha256(f'{config.get("noise_seed",0)}:{i["id"]}'.encode()).digest()[:8],'big')%(2**63-1) for i in self.images}
        self.views=2*len(self.gammas) if training and protocol!='standard' else 1
    def __len__(self): return len(self.images)*self.views
    def __getitem__(self,index):
        import numpy as np, torch
        import torch.nn.functional as F
        from PIL import Image
        view=index%self.views; im=self.images[index//self.views]
        with Image.open(Path(self.spec['image_root'])/im['file_name']) as image: x=torch.from_numpy(np.array(image.convert('RGB'),copy=True)).permute(2,0,1).float()/255
        a=self.anns[im['id']]; boxes=torch.tensor([[v['bbox'][0],v['bbox'][1],v['bbox'][0]+v['bbox'][2],v['bbox'][1]+v['bbox'][3]] for v in a],dtype=torch.float32).reshape(-1,4)
        h,w=x.shape[-2:]
        if self.config.get('model')=='fasterrcnn':
            scale=min(self.config.get('min_size',800)/min(h,w),self.config.get('max_size',1333)/max(h,w)); nh,nw=max(1,int(round(h*scale))),max(1,int(round(w*scale))); pad=(0,0)
        else:
            side=self.config.get('imgsz',640); scale=side/max(h,w); nh,nw=max(1,int(round(h*scale))),max(1,int(round(w*scale))); pad=((side-nw)//2,(side-nh)//2)
        x=F.interpolate(x[None],size=(nh,nw),mode='bilinear',align_corners=False)[0]
        sx,sy=nw/w,nh/h; boxes*=torch.tensor([sx,sy,sx,sy]); boxes+=torch.tensor([pad[0],pad[1],pad[0],pad[1]])
        if self.config.get('model')!='fasterrcnn': x=F.pad(x,(pad[0],side-nw-pad[0],pad[1],side-nh-pad[1]),value=114/255)
        if self.training and view//len(self.gammas):
            x=x.flip(-1); old=boxes.clone(); boxes[:,0]=x.shape[-1]-old[:,2]; boxes[:,2]=x.shape[-1]-old[:,0]
        def augment(z):
            gamma=self.gammas[view%len(self.gammas)] if self.views>1 else 1.
            if gamma is not None: return z.pow(gamma)
            seed=self.noise_seeds[im['id']]
            g=torch.Generator().manual_seed(seed); return (z+torch.sqrt(.01*z+.0001)*torch.randn(z.shape,generator=g)).clamp(0,1)
        mode=self.config.get('train_view' if self.training else 'test_view','raw')
        if mode not in ('raw','enhanced','mixture'): raise ValueError(f'Unknown view {mode}')
        # Mixture is resampled per epoch using an explicit deterministic seed.
        use=mode=='enhanced' or (mode=='mixture' and random.Random(f'{self.config.get("seed",0)}:{self.epoch}:{index}').random()<.5)
        def enhance(z):
            result=self.enhance(z)
            quantization=self.config.get('quantization','uint8')
            if quantization in ('uint8','8bit'): return (result*255).round().clamp(0,255)/255
            if quantization=='float': return result
            raise ValueError('quantization must be uint8 or float')
        if self.training and self.config.get('order','G-A-E')=='G-E-A': x=augment(enhance(x) if use else x)
        else:
            if self.training: x=augment(x)
            if use: x=enhance(x)
        target={'boxes':boxes,'labels':torch.tensor([self.label[v['category_id']] for v in a],dtype=torch.int64),'image_id':torch.tensor(im['id']),'area':(boxes[:,2]-boxes[:,0])*(boxes[:,3]-boxes[:,1]),'iscrowd':torch.tensor([v.get('iscrowd',0) for v in a],dtype=torch.int64),'geometry':torch.tensor([sx,sy,pad[0],pad[1],w,h])}
        return x,target

def restore_boxes(boxes,target):
    sx,sy,px,py,w,h=target['geometry'].tolist(); boxes=boxes.clone(); boxes-=boxes.new_tensor([px,py,px,py]); boxes/=boxes.new_tensor([sx,sy,sx,sy]); boxes[:,0::2].clamp_(0,w); boxes[:,1::2].clamp_(0,h); return boxes

def collate(batch): return tuple(zip(*batch))
