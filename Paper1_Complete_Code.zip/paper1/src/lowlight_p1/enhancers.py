"""Strict RGB controls and local-checkpoint inference adapters.

Four official architectures have built-in local-checkout builders. Supply repo_path
and weights_path; no code or weights are downloaded. An explicit optional factory
``relative/file.py:callable`` supports pinned variants. Checkpoint nesting,
constructor options and output contracts are recorded in provenance.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import ast

import numpy as np

OFFICIAL_REPOS = {
    "sci": "https://github.com/vis-opt-group/SCI",
    "zerodcepp": "https://github.com/Li-Chongyi/Zero-DCE_extension",
    "retinexformer": "https://github.com/caiyuanhao1998/Retinexformer",
    "pairlie": "https://github.com/zhenqifu/PairLIE",
}


def validate_rgb(image):
    x = np.asarray(image)
    if x.ndim != 3 or x.shape[2] != 3 or min(x.shape[:2]) < 1:
        raise ValueError("Expected nonempty HWC RGB image")
    if not np.issubdtype(x.dtype, np.floating):
        raise ValueError("Expected floating RGB in [0,1]; convert uint8 explicitly")
    if not np.isfinite(x).all() or x.min() < 0 or x.max() > 1:
        raise ValueError("RGB must be finite and in [0,1]")
    return np.ascontiguousarray(x, dtype=np.float32)


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def _luma(x):
    return float(np.mean(x @ np.array([0.299, 0.587, 0.114], np.float32)))


class Enhancer:
    def __init__(self, name, config=None):
        self.name = name
        self.config = dict(config or {})
        self.provenance = {"name": name, "config": self.config, "input": "float32 HWC sRGB [0,1]"}

    def __call__(self, image):
        return self.enhance(image)

    def enhance(self, image):
        x = validate_rgb(image)
        if self.name in ("raw", "identity"):
            return x.copy()
        if self.name == "gamma":
            gamma = float(self.config.get("gamma", 0.5))
            if not np.isfinite(gamma) or gamma <= 0:
                raise ValueError("gamma must be finite and positive")
            return np.power(x, gamma).astype(np.float32)
        raise NotImplementedError(self.name)


class BrightnessMatchedGamma(Enhancer):
    """Match global stated sRGB luminance of a supplied enhanced reference.

    This is a per-image control: the reference must come from the same raw image.
    Impossible targets (e.g. a black image brightened above zero) fail explicitly.
    """
    def __init__(self, target=None, **kwargs):
        super().__init__("gamma_matched", {**kwargs, "target_mean": target})
        self.target = target

    def enhance(self, image, reference=None, target_mean=None):
        x = validate_rgb(image)
        target = target_mean if target_mean is not None else self.target
        if reference is not None:
            ref = validate_rgb(reference)
            if ref.shape != x.shape:
                raise ValueError("Reference must have identical geometry")
            target = _luma(ref)
        if target is None or not np.isfinite(target) or not 0 <= target <= 1:
            raise ValueError("Provide reference or target_mean in [0,1]")
        lo, hi = 1e-6, 1e6
        maximum, minimum = _luma(x ** lo), _luma(x ** hi)
        if target < minimum - 1e-6 or target > maximum + 1e-6:
            raise ValueError("Target luminance is unreachable by gamma transform")
        for _ in range(80):
            mid = (lo * hi) ** 0.5
            if _luma(x ** mid) > target:
                lo = mid
            else:
                hi = mid
        return (x ** ((lo * hi) ** 0.5)).astype(np.float32)


class LearnedEnhancer(Enhancer):
    def __init__(self, name, config):
        super().__init__(name, config)
        if not self.config.get("repo_path") or not self.config.get("weights_path"):
            raise FileNotFoundError("Learned enhancer requires local repo_path and weights_path")
        repo = Path(self.config["repo_path"]).expanduser().resolve()
        weights = Path(self.config["weights_path"]).expanduser().resolve()
        if not repo.is_dir() or not weights.is_file():
            raise FileNotFoundError("Learned enhancer requires local repo_path and weights_path")
        import torch
        factory = self.config.get("factory")
        builtin = factory is None
        defaults = {
            "sci": ("CVPR/model.py:EnhanceNetwork", {"layers": 1, "channels": 3}),
            "zerodcepp": ("Zero-DCE++/model.py:enhance_net_nopool", {"scale_factor": 12}),
            "retinexformer": ("basicsr/models/archs/RetinexFormer_arch.py:RetinexFormer",
                              {"in_channels": 3, "out_channels": 3, "n_feat": 40, "stage": 1, "num_blocks": [1, 2, 2]}),
            "pairlie": ("net/net.py:net", {}),
        }
        default_factory, default_kwargs = defaults[name]
        if builtin and name == "sci" and not (repo / "CVPR/model.py").is_file() and (repo / "model.py").is_file():
            default_factory = "model.py:EnhanceNetwork"
        factory = factory or default_factory
        if not isinstance(factory, str) or ":" not in factory:
            raise ValueError("factory must be relative/model.py:Constructor")
        relative, symbol = factory.rsplit(":", 1)
        source = (repo / relative).resolve()
        if not source.is_relative_to(repo) or not source.is_file() or source.suffix != ".py":
            raise ValueError("Factory must be a Python file inside repo_path")
        self.device = torch.device(self.config.get("device", "cpu"))
        module_name = "_lowlight_factory_" + hashlib.sha256(str(source).encode()).hexdigest()
        spec = importlib.util.spec_from_file_location(module_name, source)
        module = importlib.util.module_from_spec(spec)
        # Official implementations often use absolute imports from checkout root.
        sys.path.insert(0, str(repo))
        try:
            if builtin and name == "sci":
                # Only the inference architecture is needed; loss.py imports
                # training-only packages and some releases allocate CUDA there.
                tree = ast.parse(source.read_text(), filename=str(source))
                tree.body = [node for node in tree.body if (
                    isinstance(node, (ast.Import, ast.ImportFrom)) and
                    not (isinstance(node, ast.ImportFrom) and node.module == "loss")) or
                    (isinstance(node, ast.ClassDef) and node.name == "EnhanceNetwork")]
                exec(compile(tree, str(source), "exec"), module.__dict__)
            elif builtin and name == "retinexformer":
                # Import the architecture only. Importing basicsr.__init__ triggers
                # unrelated datasets/CUDA extensions in official checkouts.
                tree = ast.parse(source.read_text(), filename=str(source))
                tree.body = [node for node in tree.body if not (
                    isinstance(node, ast.ImportFrom) and node.module and
                    node.module.startswith("basicsr"))]
                for node in tree.body:
                    if isinstance(node, ast.ClassDef):
                        node.decorator_list = [d for d in node.decorator_list
                            if "ARCH_REGISTRY" not in ast.unparse(d)]
                exec(compile(tree, str(source), "exec"), module.__dict__)
            else:
                spec.loader.exec_module(module)
            kwargs = dict(default_kwargs if builtin else {})
            kwargs.update(self.config.get("factory_kwargs", {}))
            model = getattr(module, symbol)(**kwargs)
        finally:
            sys.path.pop(0)
        if not isinstance(model, torch.nn.Module):
            raise TypeError("Factory must return torch.nn.Module")
        state = torch.load(weights, map_location="cpu", weights_only=True)
        key = self.config.get("state_dict_key")
        if key:
            for part in key.split("."):
                state = state[part]
        elif builtin and name == "retinexformer":
            state = state.get("params_ema", state.get("params", state))
        if builtin and name == "sci":
            # Official SCI checkpoints hold enhance.* plus training-only
            # calibrate.*. Inference is the shared single-stage EnhanceNetwork.
            prefixed = {k[len("enhance."):]: v for k, v in state.items() if k.startswith("enhance.")}
            if prefixed:
                state = prefixed
        model.load_state_dict(state, strict=True)
        self.model = model.to(self.device).eval().requires_grad_(False)
        self.multiple = int(self.config.get("pad_multiple", {"zerodcepp": 12, "retinexformer": 4}.get(name, 1)))
        if self.multiple < 1:
            raise ValueError("pad_multiple must be positive")
        self.output_contract = self.config.get("output_contract", {"sci": "sci_ir", "zerodcepp": "zerodcepp_pair", "retinexformer": "tensor", "pairlie": "pairlie_lrx"}[name])
        if builtin and name == "sci":
            self.output_contract = "sci_illumination"
        self.provenance.update({"factory": factory, "builtin": builtin, "official_repo": OFFICIAL_REPOS[name], "weights_sha256": _sha(weights),
            "source_sha256": {str(p.relative_to(repo)): _sha(p) for p in sorted(repo.rglob("*.py")) if ".git" not in p.parts},
            "pad_multiple": self.multiple, "output_contract": self.output_contract})

    def enhance(self, image):
        import torch
        import torch.nn.functional as F
        x = validate_rgb(image)
        h, w = x.shape[:2]
        t = torch.from_numpy(x.copy()).permute(2, 0, 1)[None].to(self.device)
        ph, pw = (-h) % self.multiple, (-w) % self.multiple
        # Reflection needs pad < dimension. Repeated small reflections also
        # handle tiny images without silently switching to replication.
        if (ph and h == 1) or (pw and w == 1):
            raise ValueError("Reflection padding undefined for singleton dimension")
        a, b = ph, pw
        while a or b:
            ah, bw = min(a, t.shape[-2] - 1), min(b, t.shape[-1] - 1)
            t = F.pad(t, (0, bw, 0, ah), mode="reflect")
            a -= ah
            b -= bw
        with torch.inference_mode():
            result = self.model(t)
        contract = self.output_contract
        if contract == "tensor":
            out = result
        elif contract == "sci_illumination":
            if not isinstance(result, torch.Tensor) or result.shape != t.shape:
                raise ValueError("SCI EnhanceNetwork must return RGB illumination")
            out = t / result.clamp_min(1e-4)
        elif contract in ("sci_ir", "zerodcepp_pair", "pairlie_lrx"):
            expected = 3 if contract == "pairlie_lrx" else 2
            if not isinstance(result, (tuple, list)) or len(result) != expected:
                raise ValueError(f"Expected {contract} output with {expected} tensors")
            if contract == "pairlie_lrx":
                light, reflectance, _ = result
                if not all(isinstance(v, torch.Tensor) for v in (light, reflectance)):
                    raise ValueError("PairLIE L and R must be tensors")
                if light.ndim != 4 or light.shape[0] != 1 or light.shape[1] not in (1, 3) or light.shape[-2:] != t.shape[-2:] or reflectance.shape != t.shape:
                    raise ValueError("Invalid PairLIE L/R geometry")
                out = light.pow(0.2) * reflectance
            else:
                out = result[1 if contract == "sci_ir" else 0]
        else:
            raise ValueError(f"Unknown output contract {contract!r}")
        if not isinstance(out, torch.Tensor) or out.shape != t.shape or not torch.isfinite(out).all():
            raise ValueError("Enhancer output must be finite BCHW RGB with padded input geometry")
        return out[..., :h, :w].clamp(0, 1)[0].permute(1, 2, 0).cpu().numpy().astype(np.float32)


def create_enhancer(name, config=None, **kwargs):
    config = {**dict(config or {}), **kwargs}
    name = name.lower().replace("-", "").replace("_", "").replace("++", "pp")
    if name in ("raw", "identity", "gamma"):
        return Enhancer(name, config)
    if name in ("gammamatched", "brightnessmatchedgamma"):
        return BrightnessMatchedGamma(config.get("target_mean"))
    if name in ("matchedgammasci", "matchedgammaretinexformer"):
        reference_name = "sci" if name.endswith("sci") else "retinexformer"
        reference = create_enhancer(reference_name, config.get("reference_enhancer", config))
        return ReferenceGamma(reference)
    if name in ("toneonly", "coloronly", "chromaswap", "lowfrequency", "highfrequency", "leavechromaout", "leavehighfreqout", "leavehighfrequencyout", "lowfrequencyswap", "highfrequencyswap", "leaveout", "uint8"):
        from .newtransforms import build_transform
        return build_transform(name, **config)
    if name in OFFICIAL_REPOS:
        return LearnedEnhancer(name, config)
    raise ValueError(f"Unknown enhancer {name!r}; supported: raw, identity, gamma, gamma_matched, {', '.join(OFFICIAL_REPOS)}")


def cached_enhance(enhancer, image, cache_dir):
    """Content/provenance-addressed, atomic float32 cache; rejects corrupt entries."""
    x = validate_rgb(image)
    provenance = dict(enhancer.provenance)
    provenance["implementation_sha256"] = _sha(Path(__file__))
    transforms = Path(__file__).with_name("newtransforms.py")
    if transforms.exists():
        provenance["transforms_sha256"] = _sha(transforms)
    manifest = json.dumps(provenance, sort_keys=True, default=str).encode()
    key = hashlib.sha256(manifest + str(x.shape).encode() + x.tobytes()).hexdigest()
    directory = Path(cache_dir)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / (key + ".npy")
    metadata_path = directory / (key + ".json")
    if path.exists():
        out = validate_rgb(np.load(path, allow_pickle=False))
        if out.shape != x.shape:
            raise ValueError("Cached image geometry mismatch")
        if not metadata_path.exists():
            raise ValueError("Cache provenance sidecar missing (incomplete cache write)")
        metadata = json.loads(metadata_path.read_text())
        if metadata.get("cache_key") != key or metadata.get("output_sha256") != hashlib.sha256(out.tobytes()).hexdigest():
            raise ValueError("Cached image checksum/provenance mismatch")
        return out
    out = validate_rgb(enhancer(x))
    if out.shape != x.shape:
        raise ValueError("Enhancer changed image geometry")
    fd, temp = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            np.save(f, out, allow_pickle=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
        metadata = {"cache_key": key, "input_sha256": hashlib.sha256(x.tobytes()).hexdigest(),
                    "output_sha256": hashlib.sha256(out.tobytes()).hexdigest(),
                    "shape": list(x.shape), "dtype": "float32", "provenance": provenance,
                    "diagnostics": getattr(enhancer, "last_diagnostics", {})}
        meta_fd, meta_temp = tempfile.mkstemp(dir=directory, suffix=".json.tmp")
        try:
            with os.fdopen(meta_fd, "w") as f:
                json.dump(metadata, f, sort_keys=True, default=str)
                f.flush()
                os.fsync(f.fileno())
            os.replace(meta_temp, metadata_path)
        finally:
            if os.path.exists(meta_temp):
                os.unlink(meta_temp)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    return out


class ReferenceGamma(BrightnessMatchedGamma):
    def __init__(self, reference):
        super().__init__()
        self.reference = reference
        self.provenance["reference"] = reference.provenance

    def enhance(self, image):
        return super().enhance(image, reference=self.reference(image))


get_enhancer = create_enhancer
