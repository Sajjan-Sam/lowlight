"""Stored-prediction analysis. AP requires optional pycocotools, imported lazily."""
import contextlib
import csv
import io
import json
from pathlib import Path
import numpy as np
from .core import atomic_json, sha256
from .statistics import paired_bootstrap, paired_permutation, holm


def coco_metrics(gt, predictions, max_det=100, category_ids=None, image_ids=None):
    try:
        from pycocotools.coco import COCO
        from pycocotools.cocoeval import COCOeval
    except ImportError as e:
        raise RuntimeError('COCO AP analysis requires pycocotools in the selected environment. Supply an environment with it installed; no packages were installed.') from e
    with contextlib.redirect_stdout(io.StringIO()):
        g=COCO(); g.dataset=dict(gt); g.dataset.setdefault('info',{}); g.createIndex()
        if predictions: d=g.loadRes(predictions)
        else:
            d=COCO(); d.dataset={'images':gt['images'],'categories':gt['categories'],'annotations':[]}; d.createIndex()
        ev=COCOeval(g,d,'bbox'); ev.params.maxDets=[1,10,max_det]
        if category_ids is not None: ev.params.catIds=list(category_ids)
        if image_ids is not None: ev.params.imgIds=list(image_ids)
        ev.evaluate(); ev.accumulate()
    p=ev.eval['precision']; r=ev.eval['recall']
    def avg(a):
        valid=a[a>=0]; return float(valid.mean()*100) if valid.size else None
    return {'AP':avg(p[:,:,:,0,-1]),'AP50':avg(p[np.isclose(ev.params.iouThrs,.5),:,:,0,-1]),'AP75':avg(p[np.isclose(ev.params.iouThrs,.75),:,:,0,-1]),'AP_small':avg(p[:,:,:,1,-1]),'AP_medium':avg(p[:,:,:,2,-1]),'AP_large':avg(p[:,:,:,3,-1]),'ARmax':avg(r[:,:,0,-1])}


def box_iou(a,b):
    ax,ay,aw,ah=a; bx,by,bw,bh=b
    inter=max(0,min(ax+aw,bx+bw)-max(ax,bx))*max(0,min(ay+ah,by+bh)-max(ay,by))
    union=aw*ah+bw*bh-inter
    return inter/union if union>0 else 0.


def matched_objects(gt, predictions, iou_threshold=.5, confidence_threshold=.05):
    """Greedy score-ordered category matching; diagnostic, not COCO crowd evaluation."""
    if any(a.get('iscrowd',0) or a.get('ignore',0) for a in gt['annotations']): raise ValueError('Matched-object diagnostics require crowd/ignore-free annotations')
    annotations={a['id']:a for a in gt['annotations']}; available=set(annotations); matches={}
    for p in sorted(predictions,key=lambda x:x['score'],reverse=True):
        if p['score']<confidence_threshold: continue
        candidates=[(box_iou(p['bbox'],annotations[k]['bbox']),k) for k in available if annotations[k]['image_id']==p['image_id'] and annotations[k]['category_id']==p['category_id']]
        if candidates:
            overlap,key=max(candidates)
            if overlap>=iou_threshold:
                available.remove(key); matches[key]=(overlap,p['score'])
    return [{'annotation_id':a['id'],'image_id':a['image_id'],'category_id':a['category_id'],'matched':int(a['id'] in matches),'iou':matches.get(a['id'],(None,None))[0],'confidence':matches.get(a['id'],(None,None))[1]} for a in gt['annotations']]


def matched_deltas(gt, baseline, treatment, **kwargs):
    a=matched_objects(gt,baseline,**kwargs); b=matched_objects(gt,treatment,**kwargs)
    return [dict(annotation_id=x['annotation_id'],image_id=x['image_id'],category_id=x['category_id'],recall_delta=y['matched']-x['matched'],iou_delta=y['iou']-x['iou'] if x['matched'] and y['matched'] else None,confidence_delta=y['confidence']-x['confidence'] if x['matched'] and y['matched'] else None,both_matched=int(x['matched'] and y['matched'])) for x,y in zip(a,b)]


def linear_cka(x,y):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if x.ndim!=2 or y.ndim!=2 or len(x)!=len(y) or len(x)<2: raise ValueError('Paired 2D features with at least two ROIs required')
    x=x-x.mean(0); y=y-y.mean(0)
    denominator=np.linalg.norm(x.T@x)*np.linalg.norm(y.T@y)
    if denominator==0: raise ValueError('CKA undefined for constant features')
    return float(np.linalg.norm(x.T@y)**2/denominator)


def rbf_mmd(x,y,bandwidth):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if x.ndim!=2 or y.ndim!=2 or x.shape[1]!=y.shape[1] or min(len(x),len(y))<2 or bandwidth<=0: raise ValueError('MMD needs compatible samples n>=2 and positive predeclared bandwidth')
    def kernel(a,b): return np.exp(-np.maximum(0,(a*a).sum(1)[:,None]+(b*b).sum(1)[None,:]-2*a@b.T)/(2*bandwidth**2))
    xx=kernel(x,x); yy=kernel(y,y)
    return float((xx.sum()-np.trace(xx))/(len(x)*(len(x)-1))+(yy.sum()-np.trace(yy))/(len(y)*(len(y)-1))-2*kernel(x,y).mean())


def feature_analysis(npz_path, bandwidth):
    """NPZ: baseline/treatment [N,D], roi_ids [N], strata [N]. Rows paired."""
    with np.load(npz_path,allow_pickle=False) as z:
        x=z['baseline']; y=z['treatment']; ids=z['roi_ids']; strata=z['strata']
        if len(ids)!=len(set(ids.tolist())) or len(ids)!=len(x) or len(strata)!=len(x) or len(y)!=len(x): raise ValueError('Unique aligned ROI IDs and strata required')
        rows=[]
        for group in np.unique(strata):
            mask=strata==group
            if mask.sum()<2: continue
            rows.append({'stratum':str(group),'n':int(mask.sum()),'linear_CKA':linear_cka(x[mask],y[mask]),'unbiased_RBF_MMD2':rbf_mmd(x[mask],y[mask],bandwidth),'bandwidth':bandwidth})
        return rows


def paired_feature_analysis(baseline_path, treatment_path, bandwidth, feature_key=None):
    """Join backend NPZ descriptors by explicit IDs, never by row position.

    ROI keys end /roi, joined by globally unique COCO object_ids, stratified by
    category_ids. Global keys end /global, joined by image_ids. Both artifacts
    must contain exactly the same ID population; silent intersections are refused.
    """
    with np.load(baseline_path,allow_pickle=False) as aa, np.load(treatment_path,allow_pickle=False) as bb:
        keys=[feature_key] if feature_key else sorted(k for k in aa.files if k.endswith(('/roi','/global')))
        if not keys: raise ValueError('No backend descriptor arrays found')
        rows=[]
        for key in keys:
            if key not in aa or key not in bb: raise ValueError(f'Missing matching descriptor: {key}')
            is_roi=key.endswith('/roi'); id_key='object_ids' if is_roi else 'image_ids'
            aid=aa[id_key].tolist(); bid=bb[id_key].tolist()
            if len(set(aid))!=len(aid) or len(set(bid))!=len(bid) or set(aid)!=set(bid): raise ValueError(f'Unique identical {id_key} populations required')
            lookup={uid:i for i,uid in enumerate(bid)}; order=[lookup[uid] for uid in aid]
            x=aa[key]; y=bb[key][order]
            if len(x)!=len(aid) or len(y)!=len(aid): raise ValueError('Descriptor rows differ from explicit ID arrays')
            strata=aa['category_ids'] if is_roi else np.full(len(aid),'all')
            if is_roi and not np.array_equal(strata,bb['category_ids'][order]): raise ValueError('Category labels differ for paired object IDs')
            for group in np.unique(strata):
                mask=strata==group
                if mask.sum()<2: continue
                rows.append({'feature':key,'stratum':str(group),'n':int(mask.sum()),'linear_CKA':linear_cka(x[mask],y[mask]),'unbiased_RBF_MMD2':rbf_mmd(x[mask],y[mask],bandwidth),'bandwidth':bandwidth})
        return rows


def write_csv(path,rows):
    if not rows: return
    with open(path,'w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def run_analysis(config, results_root=None):
    """Config: ground_truth path, conditions {name:[prediction JSON paths]}, optional
    baseline, comparisons [[baseline,treatment]], n_boot,n_perm,cluster_key,max_det,
    lighting_key,feature_npz,mmd_bandwidth. Paths relative to results_root (or cwd).
    Seed list positions MUST identify the same training seed across conditions.
    """
    root=Path(results_root or '.'); cfg=json.loads(Path(config).read_text()) if isinstance(config,(str,Path)) else config
    def read(p): return json.loads((root/p).read_text())
    gt=read(cfg['ground_truth']); conditions={name:[read(p) for p in paths] for name,paths in cfg['conditions'].items()}
    if not conditions or any(not seeds for seeds in conditions.values()): raise ValueError('Nonempty condition seed lists required')
    known={i['id'] for i in gt['images']}; cats={c['id'] for c in gt['categories']}
    for seeds in conditions.values():
        for predictions in seeds:
            for p in predictions:
                if p['image_id'] not in known or p['category_id'] not in cats or not np.isfinite(p['score']) or len(p['bbox'])!=4 or not np.isfinite(p['bbox']).all() or min(p['bbox'][2:])<0: raise ValueError('Invalid prediction record')
    out=root/cfg.get('analysis_output','analysis'); out.mkdir(parents=True,exist_ok=True)
    cap=cfg.get('max_det',100)
    metric=lambda g,p:coco_metrics(g,p,max_det=cap)['AP']
    rows=[]; classrows=[]; lightrows=[]
    for name,seeds in conditions.items():
        for seed,pred in enumerate(seeds):
            rows.append({'condition':name,'seed_index':seed,**coco_metrics(gt,pred,cap)})
            for cat in gt['categories']: classrows.append({'condition':name,'seed_index':seed,'class':cat['name'],**coco_metrics(gt,pred,cap,[cat['id']])})
            key=cfg.get('lighting_key','lighting')
            for level in sorted({str(im[key]) for im in gt['images'] if key in im}):
                ids=[im['id'] for im in gt['images'] if str(im.get(key))==level]
                lightrows.append({'condition':name,'seed_index':seed,'lighting':level,**coco_metrics(gt,pred,cap,image_ids=ids)})
    write_csv(out/'metrics_by_seed.csv',rows); write_csv(out/'per_class.csv',classrows); write_csv(out/'per_lighting.csv',lightrows)
    size=[{'condition':r['condition'],'seed_index':r['seed_index'],'size':s,'AP':r['AP_'+s]} for r in rows for s in ('small','medium','large')]; write_csv(out/'per_size.csv',size)
    summaries=[]
    for name in conditions:
        rr=[r for r in rows if r['condition']==name]
        summaries.append({'condition':name,'n_seeds':len(rr),**{k:float(np.mean([r[k] for r in rr if r[k] is not None])) if any(r[k] is not None for r in rr) else None for k in rows[0] if k not in ('condition','seed_index')}})
    write_csv(out/'mean_metrics.csv',summaries)
    comparisons=[]
    for a,b in cfg.get('comparisons',[]):
        kw=dict(seed=cfg.get('seed',0),cluster_key=cfg.get('cluster_key'))
        boot=paired_bootstrap(gt,conditions[a],conditions[b],metric,n_boot=cfg.get('n_boot',1000),**kw)
        perm=paired_permutation(gt,conditions[a],conditions[b],metric,n_perm=cfg.get('n_perm',999),**kw)
        draws=boot.pop('draws'); atomic_json(out/f'bootstrap_{len(comparisons)}.json',{'baseline':a,'treatment':b,'draws':draws})
        comparisons.append({'baseline':a,'treatment':b,**boot,**perm})
        for index,(pa,pb) in enumerate(zip(conditions[a],conditions[b])):
            write_csv(out/f'matched_objects_{len(comparisons)-1}_seed{index}.csv',matched_deltas(gt,pa,pb))
    for row,p in zip(comparisons,holm([r['p_value'] for r in comparisons])): row['p_holm']=p
    write_csv(out/'comparisons.csv',comparisons)
    if cfg.get('feature_npz'): write_csv(out/'feature_strata.csv',feature_analysis(root/cfg['feature_npz'],cfg['mmd_bandwidth']))
    if cfg.get('feature_pair'):
        pair=cfg['feature_pair']; write_csv(out/'paired_feature_strata.csv',paired_feature_analysis(root/pair['baseline'],root/pair['treatment'],cfg['mmd_bandwidth'],pair.get('key')))
    atomic_json(out/'analysis.json',{'metrics':summaries,'comparisons':comparisons,'config':cfg,'units':'percentage_points','seed_uncertainty':'conditional on supplied trained seeds; no prediction ensembling','input_sha256':{str(p):sha256(root/p) for p in [cfg['ground_truth']]+[p for paths in cfg['conditions'].values() for p in paths]}})
    if cfg.get('figures',True):
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
        except ImportError as e: raise RuntimeError('Figures require existing matplotlib; set figures=false to produce tables only') from e
        fig,ax=plt.subplots(figsize=(max(5,len(summaries)),4))
        for index,r in enumerate(summaries):
            values=[x['AP'] for x in rows if x['condition']==r['condition'] and x['AP'] is not None]
            ax.scatter([index]*len(values),values,color='black'); ax.plot([index-.2,index+.2],[r['AP']]*2,color='tab:blue')
        ax.set_xticks(range(len(summaries)),[r['condition'] for r in summaries],rotation=30,ha='right'); ax.set_ylabel('COCO AP (percentage points)'); fig.tight_layout()
        for ext in ('png','pdf'): fig.savefig(out/f'AP_by_seed.{ext}')
        plt.close(fig)
    return out


def run_tide(ground_truth_path,predictions_path,output_dir):
    try: from tidecv import TIDE, datasets
    except ImportError as e: raise RuntimeError('Optional TIDE requires existing tidecv; no packages were installed') from e
    tide=TIDE(); tide.evaluate(datasets.COCO(str(ground_truth_path)),datasets.COCOResult(str(predictions_path)),mode=TIDE.BOX); tide.summarize(); tide.plot(out_dir=str(output_dir))
    return tide
