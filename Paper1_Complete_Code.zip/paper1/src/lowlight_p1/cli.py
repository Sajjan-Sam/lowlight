"""Offline-safe command entry points and immutable run provenance."""
import argparse
import copy
import csv
import json
import platform
from pathlib import Path
from .core import atomic_json, read_config, run_lock, sha256, validate_data

ALLOWED = set('run_id output_root seed model initial_weights device epochs batch_size lr num_workers resume train_view test_view enhancer protocol data fraction frozen update_policy max_updates update_milestones min_size max_size max_det milestones imgsz optimizer amp conf nms_iou dataset group evaluation_enhancers augmentation_bank experiment order quantization subset_seed noise_seed source_only source_category_map feature_layers final_lr_fraction momentum weight_decay clip_grad final_refit'.split())

def check_config(c):
    if not isinstance(c, dict): raise ValueError('Config must be an object')
    unknown=set(c)-ALLOWED
    if unknown: raise ValueError(f'Unknown configuration fields: {sorted(unknown)}')
    run=c.get('run_id','')
    if not run or Path(run).name!=run or run in ('.','..'): raise ValueError('run_id must be a single safe directory name')
    if c.get('protocol','standard') not in ('standard','exact_six_view'): raise ValueError('Unknown protocol')
    if c.get('update_policy','equal_epochs') not in ('equal_epochs','equal_updates'): raise ValueError('Unknown update policy')
    if c.get('update_policy')=='equal_updates' and (type(c.get('max_updates')) is not int or c['max_updates']<1): raise ValueError('equal_updates requires positive max_updates')
    if not 0<float(c.get('fraction',1))<=1: raise ValueError('fraction must be in (0,1]')
    for name in ('train_view','test_view'):
        if c.get(name,'raw') not in ('raw','enhanced','mixture'): raise ValueError(f'Invalid {name}')
    if c.get('test_view')=='mixture': raise ValueError('Test mixture is stochastic; choose raw or enhanced')
    if c.get('model','yolov8n') not in ('yolov8n','yolov8s','yolov8m','rtdetr-l','fasterrcnn'): raise ValueError('Unknown detector')
    return c

def manifest_configs(path, base):
    path=Path(path)
    if path.suffix=='.json': rows=json.loads(path.read_text())
    else:
        with path.open(newline='') as stream: rows=list(csv.DictReader(stream))
    if not isinstance(rows,list) or not rows: raise ValueError('Manifest must contain rows')
    results=[]; seen=set()
    for row in rows:
        if not isinstance(row,dict) or not row.get('run_id'): raise ValueError('Each manifest row requires run_id')
        c=copy.deepcopy(base)
        if row.get('config_path'):
            cp=Path(row['config_path']); cp=cp if cp.is_absolute() else path.parent/cp
            c=read_config(cp)
            if c.get('run_id')!=row['run_id']: raise ValueError('Manifest/config run_id mismatch')
        for key,value in row.items():
            if key=='config_path': continue
            if key is None or value is None: raise ValueError('Malformed manifest row')
            if value=='': continue
            if isinstance(value,str) and key!='run_id':
                try: value=json.loads(value)
                except json.JSONDecodeError: pass
            parts=key.split('.'); target=c
            for part in parts[:-1]:
                if not isinstance(target.setdefault(part,{}),dict): raise ValueError(f'Non-object manifest field {key}')
                target=target[part]
            target[parts[-1]]=value
        check_config(c)
        if c['run_id'] in seen: raise ValueError('Duplicate manifest run_id')
        seen.add(c['run_id']); results.append(c)
    return results

def training_provenance(c):
    from importlib import metadata
    versions={}
    for name in ('numpy','Pillow','torch','torchvision','ultralytics','pycocotools'):
        try: versions[name]=metadata.version(name)
        except metadata.PackageNotFoundError: versions[name]=None
    result={'python':platform.python_version(),'packages':versions,
            'initial_weights_sha256':sha256(c['initial_weights']),
            'protocol':c.get('protocol'),'seed':c['seed'],
            'runner_source_sha256':{p.name:sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}}
    enhancer=c.get('enhancer',{})
    if enhancer.get('weights_path'): result['enhancer_weights_sha256']=sha256(enhancer['weights_path'])
    if enhancer.get('repo_path'):
        repo=Path(enhancer['repo_path'])
        result['enhancer_source_sha256']={str(p.relative_to(repo)):sha256(p) for p in sorted(repo.rglob('*.py')) if '.git' not in p.parts}
    return result

def execute(command,c,split='dev', manifest=None, view=None, enhancer_config=None):
    check_config(c)
    directory=Path(c['output_root']).expanduser()/c['run_id']
    with run_lock(directory):
        snapshot=directory/'config.json'
        # resume is operational; all experimental fields must remain immutable.
        identity={k:v for k,v in c.items() if k!='resume'}
        if snapshot.exists():
            old=json.loads(snapshot.read_text())
            if {k:v for k,v in old.items() if k!='resume'}!=identity: raise ValueError('Run directory already belongs to a different configuration')
        else: atomic_json(snapshot,c)
        if manifest: atomic_json(directory/'manifest_source.json',manifest)
        try:
            atomic_json(directory/'status.json',{'state':'running','command':command})
            if command in ('validate-data','run','train','predict','evaluate','features'):
                result=validate_data(c)
                report=directory/'data_validation.json'
                if report.exists() and json.loads(report.read_text())!=result: raise ValueError('Dataset contents changed since previous run')
                atomic_json(report,result)
            if command!='validate-data':
                if view is not None:
                    c=copy.deepcopy(c); c['test_view']=view
                    if enhancer_config is not None: c['enhancer']=enhancer_config
                    import hashlib
                    tag=hashlib.sha256(json.dumps({'view':view,'enhancer':c.get('enhancer',{})},sort_keys=True).encode()).hexdigest()[:12]
                    c['_artifact_tag']='_'+view+'_'+tag
                from . import engine
                if command in ('train','run'):
                    engine.preflight(c)
                    provenance=training_provenance(c)
                    record=directory/'provenance.json'
                    if record.exists() and json.loads(record.read_text())!=provenance: raise ValueError('Checkpoint or runtime provenance changed since previous run')
                    atomic_json(record,provenance)
                    engine.train(c,directory)
                if command in ('predict','run'): engine.predict(c,directory,split)
                if command in ('evaluate','run'): engine.evaluate(c,directory,split)
                if command=='features': engine.extract_features(c,directory,split)
            atomic_json(directory/'status.json',{'state':'complete','command':command})
        except Exception as error:
            atomic_json(directory/'status.json',{'state':'failed','command':command,'error':str(error),'error_type':type(error).__name__})
            raise
    return directory

def main(argv=None):
    parser=argparse.ArgumentParser(description='Paper 1 offline reproducible study')
    subs=parser.add_subparsers(dest='command',required=True)
    for command in ('validate-data','train','predict','evaluate','features','run','manifest','prepare','plan','doctor','status','study-evaluate','analyze'):
        sub=subs.add_parser(command); sub.add_argument('--config',required=True)
        if command in ('predict','evaluate','features','run','manifest','study-evaluate'): sub.add_argument('--split',choices=('dev','test'),default='dev')
        if command in ('predict','evaluate','features','manifest'):
            sub.add_argument('--view',choices=('raw','enhanced')); sub.add_argument('--enhancer-config')
        if command in ('manifest','status','study-evaluate'): sub.add_argument('--manifest',required=True)
        if command=='manifest':
            sub.add_argument('--row-index',type=int); sub.add_argument('--validate-only',action='store_true'); sub.add_argument('--stage',choices=('train','predict','evaluate','run'),default='train')
        if command=='prepare': sub.add_argument('--dataset')
        if command=='plan':
            sub.add_argument('--profile',choices=('pilot','full'),default='pilot'); sub.add_argument('--output',required=True)
    args=parser.parse_args(argv)
    try:
        c=read_config(args.config); provenance=None; command=args.command
        if command=='analyze':
            from .analysis import run_analysis
            print(run_analysis(c)); return 0
        if command=='prepare':
            from .prepare import prepare
            if 'datasets' in c:
                names=[args.dataset] if args.dataset else list(c['datasets'])
                for name in names:
                    entry=c['datasets'][name]
                    if 'prepare' not in entry: raise ValueError(f'{name}: add native converter settings under datasets.{name}.prepare; see docs/data_layout.md')
                    result=prepare(entry['prepare']); entry['data']=result['data']; entry['train_all']=result['train_all']
                out=Path(args.config).with_name('resolved_project.json'); atomic_json(out,c); print(out)
            else: print(json.dumps(prepare(c)))
            return 0
        if command in ('plan','doctor','status'):
            from . import study
            if command=='plan': result=study.plan(c,args.profile,args.output)
            elif command=='doctor': result=study.doctor(c)
            else: result=study.status(c,args.manifest)
            print(json.dumps(result,default=str)); return 0
        if command=='study-evaluate':
            rows=manifest_configs(args.manifest,c)
            for row in rows:
                views=[('raw',None)]
                for label in row.get('evaluation_enhancers',[]):
                    from .study import _enhancer
                    enhancer=_enhancer(c,label)
                    views.append(('enhanced',enhancer))
                if row.get('train_view')!='raw' and row.get('enhancer'): views.append(('enhanced',row['enhancer']))
                for enhancer in c.get('evaluation_controls',{}).values(): views.append(('enhanced',enhancer))
                seen=set()
                for view,enhancer in views:
                    key=json.dumps([view,enhancer],sort_keys=True)
                    if key in seen: continue
                    seen.add(key)
                    execute('predict',row,args.split,view=view,enhancer_config=enhancer)
                    execute('evaluate',row,args.split,view=view,enhancer_config=enhancer)
            print(json.dumps({'evaluated_runs':len(rows),'split':args.split})); return 0
        if command=='manifest':
            rows=manifest_configs(args.manifest,c)
            if args.validate_only: print(json.dumps({'valid_rows':len(rows)})); return 0
            if args.row_index is None or not 0<=args.row_index<len(rows): raise ValueError('--row-index must select a zero-based manifest row')
            c=rows[args.row_index]; command=args.stage; provenance={'path':str(Path(args.manifest).resolve()),'sha256':sha256(args.manifest),'row_index':args.row_index}
        enhancer=json.loads(args.enhancer_config) if getattr(args,'enhancer_config',None) else None
        if enhancer is not None and (not isinstance(enhancer,dict) or getattr(args,'view',None) is None): raise ValueError('--enhancer-config requires --view and a JSON object')
        print(execute(command,c,getattr(args,'split','dev'),provenance,getattr(args,'view',None),enhancer)); return 0
    except Exception as error:
        parser.exit(1,f'{type(error).__name__}: {error}\n')
