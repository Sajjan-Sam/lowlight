"""Controlled float-tensor Ultralytics training without native data augmentation.

Uses the public DetectionModel/RTDETRDetectionModel loss batch contract. Native
checkpoint metadata is retained so native predictors can load the result.
"""
import copy, math, os, random, time
from pathlib import Path
from .core import atomic_json
from .data import CocoDataset, collate

def ultra_batch(images,targets,device):
    import torch
    rows=[]; classes=[]; indices=[]
    for j,(im,t) in enumerate(zip(images,targets)):
        b=t['boxes'].clone(); h,w=im.shape[-2:]
        center=(b[:,:2]+b[:,2:])/2; wh=b[:,2:]-b[:,:2]
        rows.append(torch.cat((center,wh),1)/b.new_tensor([w,h,w,h])); classes.append(t['labels']-1); indices.append(torch.full((len(b),),j))
    return {'img':torch.stack(images).to(device),'bboxes':torch.cat(rows).to(device),'cls':torch.cat(classes).float().view(-1,1).to(device),'batch_idx':torch.cat(indices).to(device)}

def train_controlled(c,d):
    import numpy as np, torch
    from torch.utils.data import DataLoader
    from .engine import ultra_offline_classes
    YOLO,RTDETR=ultra_offline_classes()
    from ultralytics.cfg import get_cfg
    wrapper=(RTDETR if c['model']=='rtdetr-l' else YOLO)(c['initial_weights'])
    dataset=CocoDataset(c['data']['train'],c,True)
    if any(a.get('iscrowd',0) for a in dataset.coco['annotations']): raise ValueError('Controlled training requires crowd-free annotations')
    # Rebuild only the task head, transferring compatible pretrained tensors.
    from ultralytics.nn.tasks import DetectionModel, RTDETRDetectionModel
    cls=RTDETRDetectionModel if c['model']=='rtdetr-l' else DetectionModel
    model=cls(cfg=copy.deepcopy(wrapper.model.yaml),nc=len(dataset.categories),verbose=False)
    model.load(wrapper.model,verbose=False); model.args=get_cfg(overrides={'box':7.5,'cls':.5,'dfl':1.5})
    model.names={i:x['name'] for i,x in enumerate(sorted(dataset.coco['categories'],key=lambda x:x['id']))}
    device=torch.device(c.get('device','cuda')); model.to(device)
    frozen=[]
    if c.get('frozen',False):
        # Ultralytics YAML backbone entry count defines the frozen boundary.
        boundary=len(model.yaml['backbone'])
        for layer in list(model.model)[:boundary]: layer.requires_grad_(False); frozen.append(layer)
    optimizer=torch.optim.SGD([p for p in model.parameters() if p.requires_grad],lr=c.get('lr',.01),momentum=c.get('momentum',.937),weight_decay=c.get('weight_decay',.0005))
    generator=torch.Generator().manual_seed(c['seed'])
    loader=DataLoader(dataset,batch_size=c.get('batch_size',16),shuffle=True,generator=generator,num_workers=c.get('num_workers',0),collate_fn=collate,drop_last=True)
    if not len(loader): raise ValueError('Subset bank smaller than effective batch; reduce batch_size')
    policy=c.get('update_policy','equal_epochs'); budget=c.get('max_updates') if policy=='equal_updates' else c.get('epochs',100)*len(loader)
    if not isinstance(budget,int) or budget<1: raise ValueError('Positive integer max_updates required for equal_updates')
    epochs=math.ceil(budget/len(loader)); d=Path(d); native=d/'native'/'weights'; native.mkdir(parents=True,exist_ok=True); checkpoint=native/'last.pt'; statefile=d/'training_state.pt'; updates=0; start=0
    if statefile.exists() and c.get('resume',True):
        state=torch.load(statefile,map_location='cpu',weights_only=False); model.load_state_dict(state['model']); optimizer.load_state_dict(state['optimizer']); updates=state['updates']; start=state['epoch']+1
        random.setstate(state['python_rng']); np.random.set_state(state['numpy_rng']); torch.set_rng_state(state['torch_rng']); generator.set_state(state['loader_rng'])
        if torch.cuda.is_available() and state['cuda_rng'] is not None: torch.cuda.set_rng_state_all(state['cuda_rng'])
    started=time.time()
    for epoch in range(start,epochs):
        dataset.epoch=epoch; model.train()
        for layer in frozen: layer.eval()
        losses=[]
        for images,targets in loader:
            if updates>=budget: break
            progress=updates/max(1,budget-1); factor=(1-progress)*(1-c.get('final_lr_fraction',.01))+c.get('final_lr_fraction',.01)
            for group in optimizer.param_groups: group['lr']=c.get('lr',.01)*factor
            optimizer.zero_grad(set_to_none=True); loss,_=model(ultra_batch(images,targets,device)); loss=loss.sum()
            if not torch.isfinite(loss): raise RuntimeError(f'Nonfinite loss at update {updates}')
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),c.get('clip_grad',10.)); optimizer.step(); updates+=1; losses.append(float(loss.detach()))
        state={'model':model.state_dict(),'optimizer':optimizer.state_dict(),'updates':updates,'epoch':epoch,'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,'loader_rng':generator.get_state(),'categories':dataset.categories}
        tmp=d/'training_state.tmp.pt'; torch.save(state,tmp); os.replace(tmp,statefile)
        # Native loaders require a module, train_args and version metadata.
        import ultralytics
        payload={'model':copy.deepcopy(model).cpu().float(),'ema':None,'optimizer':None,'epoch':epoch,'train_args':{'task':'detect','imgsz':c.get('imgsz',640)},'version':ultralytics.__version__}
        tmp=native/'last.tmp.pt'; torch.save(payload,tmp); os.replace(tmp,checkpoint)
        atomic_json(d/'progress.json',{'epoch':epoch+1,'updates':updates,'loss':sum(losses)/max(1,len(losses)),'seconds':time.time()-started,'distinct_images':len(dataset.images),'repeat_exposures':updates*c.get('batch_size',16)/len(dataset.images),'subset_ids':[i['id'] for i in dataset.images],'noise_seeds':dataset.noise_seeds if c.get('augmentation_bank')=='strong' else {}})
    return checkpoint
