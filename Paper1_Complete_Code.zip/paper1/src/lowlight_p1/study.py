"""Deterministic registered-study planning and offline prerequisite reports."""
import copy
import csv
import importlib.util
import json
from collections import Counter
from pathlib import Path
from .core import atomic_json, sha256

MODELS=('yolov8n','fasterrcnn','rtdetr-l')
DATASETS=('exdark','darkface','nod')
GROUP_COUNTS={'C':189,'O':24,'A':18,'Q':12,'K':18,'S':54,'F':72,'E':54,'M':12}

def _budget(project,dataset):
    value=project.get('max_updates')
    if isinstance(value,dict): value=value.get(dataset)
    if value is not None:
        if type(value) is not int or value<1: raise ValueError('max_updates must be a positive integer or dataset mapping')
        return value
    entry=project['datasets'][dataset]
    spec=entry.get('train_all') if project.get('final_refit',False) else entry['data']['train']
    if not spec: raise ValueError('final_refit requires train_all')
    path=Path(spec['annotations'])
    if not path.is_file(): raise ValueError(f'Full planning needs prepared {dataset} training annotations or explicit max_updates; missing {path}')
    count=len(json.loads(path.read_text())['images'])*6
    # drop_last=True is shared by the fixed-update training loaders.
    steps=count//int(project.get('batch_size',8))
    if steps<1: raise ValueError('Full dataset has fewer views than batch_size')
    return steps*int(project.get('epochs',100))

def _enhancer(project,key):
    if key=='raw': return {'name':'identity'}
    if key in ('GS','GR'):
        source='SCI' if key=='GS' else 'RF'
        return {'name':'matched_gamma_sci' if source=='SCI' else 'matched_gamma_retinexformer','reference_enhancer':copy.deepcopy(project['enhancers'][source])}
    return copy.deepcopy(project['enhancers'][key])

def plan(project,profile,output):
    if profile not in ('pilot','full'): raise ValueError('profile must be pilot or full')
    for d in DATASETS if profile=='full' else DATASETS[:2]:
        if d not in project.get('datasets',{}): raise ValueError(f'Missing dataset {d}')
    cells=[]
    def add(group,dataset,model,representation,seed,**changes):
        raw=representation=='raw'; key=representation.split('-')[1] if not raw else 'raw'
        view='raw' if raw else ('mixture' if representation.startswith('P4-') else 'enhanced')
        c={k:copy.deepcopy(project[k]) for k in ('device','epochs','batch_size','num_workers','lr','optimizer','imgsz','min_size','max_size','amp','feature_layers','max_det','conf','nms_iou','milestones') if k in project}
        c.update({'output_root':project.get('output_root',project['work_root']),'seed':seed,'model':model,'initial_weights':project['weights'][model],
                  'protocol':'exact_six_view','quantization':'float' if representation.endswith('-float') else 'uint8','resume':True,'train_view':view,'test_view':'raw','enhancer':_enhancer(project,key),
                  'data':copy.deepcopy(project['datasets'][dataset]['data']),'dataset':dataset,'group':'P1-'+group,'fraction':1.,'frozen':False,
                  'evaluation_enhancers':(['SCI','ZD','RF','PL','GS','GR'] if raw and group=='C' else ['SCI','RF'] if raw else [key])})
        c.update(changes)
        if project.get('final_refit',False):
            spec=project['datasets'][dataset].get('train_all')
            if not spec: raise ValueError(f'{dataset}: final_refit requires prepared train_all spec')
            c['final_refit']=True; c['data']['train']=copy.deepcopy(spec)
        suffix=''.join('_'+str(k)+'-'+str(v).replace('.','p') for k,v in sorted(changes.items()) if k in ('fraction','order','augmentation_bank','frozen','update_policy'))
        c['run_id']=f'p1{group.lower()}_{dataset}_{model}_{representation.lower()}_s{seed}{suffix}'
        cells.append(c)
    if profile=='pilot':
        for d in DATASETS[:2]:
            for rep in ('raw','P3-SCI','P3-RF','P4-SCI','P4-RF'): add('C',d,'yolov8n',rep,0)
    else:
        for d in DATASETS:
            for m in MODELS:
                for rep in ('raw','P3-SCI','P3-ZD','P3-RF','P3-PL','P4-SCI','P4-RF'):
                    for s in range(3): add('C',d,m,rep,s)
        for d in DATASETS[:2]:
            for e in ('SCI','RF'):
                for order in ('G-A-E','G-E-A'):
                    for s in range(3): add('O',d,'yolov8n','P3-'+e,s,experiment='order',order=order)
            for rep in ('raw','P3-SCI','P3-RF'):
                for s in range(3): add('A',d,'yolov8n',rep,s,augmentation_bank='strong',noise_seed=0,update_policy='equal_updates',max_updates=_budget(project,d))
            for group in ('S','F','E'):
                for fraction in ((.1,.25,.5,1.) if group=='F' else (.1,.25,.5)):
                    for rep in ('raw','P3-SCI','P3-RF'):
                        for s in range(3):
                            opts={'fraction':fraction,'subset_seed':s,'frozen':group=='F','update_policy':'equal_epochs' if group=='E' else 'equal_updates'}
                            if group!='E': opts['max_updates']=_budget(project,d)
                            add(group,d,'yolov8n',rep,s,**opts)
        for rep in ('P3-GS','P3-GR','P3-SCI-float','P3-RF-float'):
            for s in range(3): add('Q','exdark','yolov8n',rep,s)
        for m in ('yolov8s','yolov8m'):
            for rep in ('raw','P3-SCI','P3-RF'):
                for s in range(3): add('K','exdark',m,rep,s)
        for e in ('SCI','RF'):
            for variant in ('tone_only','high_frequency_swap'):
                for s in range(3): add('M','exdark','yolov8n','P3-'+e+'-'+variant,s,enhancer={'name':variant,'reference_enhancer':_enhancer(project,e)})
        actual=Counter(c['group'][3:] for c in cells)
        if dict(actual)!=GROUP_COUNTS: raise AssertionError(f'Invalid study matrix: {actual}')
    ids=[c['run_id'] for c in cells]
    if len(set(ids))!=len(ids): raise AssertionError('Duplicate training identities')
    output=Path(output).resolve(); config_dir=output.parent/(output.stem+'_configs')
    # Check all immutable files before writing any; rerunning an identical plan is safe.
    for c in cells:
        path=config_dir/(c['run_id']+'.json')
        if path.exists() and json.loads(path.read_text())!=c: raise ValueError(f'Existing planned config differs: {path}')
    output.parent.mkdir(parents=True,exist_ok=True)
    rows=[{'run_id':c['run_id'],'config_path':str(config_dir/(c['run_id']+'.json'))} for c in cells]
    if output.exists():
        with output.open(newline='') as f: old=list(csv.DictReader(f))
        if old!=rows: raise ValueError(f'Refusing to replace different manifest {output}')
    for c in cells: atomic_json(config_dir/(c['run_id']+'.json'),c)
    with output.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=('run_id','config_path')); writer.writeheader(); writer.writerows(rows)
    report={'profile':profile,'trainings':len(cells),'groups':dict(Counter(c['group'] for c in cells)),'manifest':str(output),'manifest_sha256':sha256(output)}
    atomic_json(output.with_suffix('.plan.json'),report)
    return report

def doctor(project):
    checks=[]
    def check(kind,path):
        checks.append({'kind':kind,'path':str(path),'available':bool(path) and Path(path).exists()})
    for model,path in project.get('weights',{}).items(): check('detector:'+model,path)
    for key,c in project.get('enhancers',{}).items():
        for field in ('repo_path','weights_path'): check('enhancer:'+key+':'+field,c.get(field,''))
    for name,d in project.get('datasets',{}).items():
        for split,spec in d.get('data',{}).items():
            for field in ('annotations','image_root'): check(name+':'+split+':'+field,spec.get(field,''))
    packages={name:importlib.util.find_spec(name) is not None for name in ('torch','torchvision','numpy','PIL','pycocotools','ultralytics')}
    return {'ready':all(c['available'] for c in checks) and all(packages.values()),'paths':checks,'packages':packages,'qualification':'Path/import discovery only; GPU, checkpoint loading and metric agreement require allocated qualification.'}

def status(project,manifest):
    with Path(manifest).open(newline='') as f: rows=list(csv.DictReader(f))
    results=[]
    for row in rows:
        c=json.loads(Path(row['config_path']).read_text()); directory=Path(c['output_root'])/row['run_id']; path=directory/'status.json'
        record=json.loads(path.read_text()) if path.exists() else {'state':'pending'}
        results.append({'run_id':row['run_id'],**record,'directory':str(directory)})
    return {'counts':dict(Counter(r['state'] for r in results)),'runs':results}
