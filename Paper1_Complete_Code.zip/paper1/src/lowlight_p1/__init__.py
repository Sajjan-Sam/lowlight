"""Paper 1 auditable low-light detector experiments."""
__version__ = '0.1.0'
