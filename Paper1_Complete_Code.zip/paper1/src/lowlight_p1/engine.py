"""Native detector backends; imports remain lazy for offline inspection."""
import json, os, platform, random, time, math
from pathlib import Path
from .core import atomic_json, sha256, seed_all
from .data import CocoDataset, collate, restore_boxes

def preflight(c):
    model=c.get('model','yolov8n')
    if model not in ('yolov8n','yolov8s','yolov8m','rtdetr-l','fasterrcnn'): raise ValueError(f'Unsupported detector {model}')
    if c.get('source_only',False) and not c.get('source_category_map'): raise ValueError('source_only requires explicit source_category_map: source label -> dataset category ID')
    if c.get('protocol','exact_six_view') not in ('standard','exact_six_view','order'): raise ValueError('Unsupported protocol')
    if c.get('update_policy','equal_epochs') not in ('equal_epochs','equal_updates'): raise ValueError('Unsupported update_policy')
    if c.get('order','G-A-E') not in ('G-A-E','G-E-A'): raise ValueError('Unsupported augmentation/enhancement order')
    if c.get('quantization','uint8') not in ('uint8','8bit','float'): raise ValueError('quantization must be uint8 or float')
    if c.get('optimizer','SGD')!='SGD': raise ValueError('Controlled backend optimizer is SGD; unsupported optimizer requested')
    if c.get('amp',False): raise ValueError('Controlled backends use full precision; amp=true is unsupported')
    weights=c.get('initial_weights')
    if not weights or not Path(weights).is_file(): raise FileNotFoundError('initial_weights must be a local released checkpoint; implicit downloads/random fallback prohibited')
    if str(c.get('enhancer',{}).get('device','cpu')).startswith('cuda') and c.get('num_workers',0)>0: raise ValueError('CUDA enhancer requires num_workers=0; forking a CUDA module is unsupported')
    from .data import Enhancer
    if c.get('train_view','raw')!='raw' or c.get('test_view','raw')!='raw': Enhancer(c.get('enhancer',{}))

def make_frcnn(c,nclasses):
    import torch
    from torchvision.models.detection import fasterrcnn_resnet50_fpn
    from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
    model=fasterrcnn_resnet50_fpn(weights=None,weights_backbone=None,min_size=c.get('min_size',800),max_size=c.get('max_size',1333),box_score_thresh=.001,box_detections_per_img=c.get('max_det',1000))
    weights=torch.load(c['initial_weights'],map_location='cpu',weights_only=False)
    weights=weights.get('model',weights)
    source_classes=weights['roi_heads.box_predictor.cls_score.weight'].shape[0]
    if source_classes != model.roi_heads.box_predictor.cls_score.out_features:
        model.roi_heads.box_predictor=FastRCNNPredictor(model.roi_heads.box_predictor.cls_score.in_features,source_classes)
    model.load_state_dict(weights,strict=True) # source COCO head required, no unreported missing keys
    if c.get('frozen',False):
        model.backbone.requires_grad_(False)
    # Geometry has already been applied before enhancement. Prevent a second resize.
    import types
    def identity_resize(self, image, target=None): return image,target
    model.transform.resize=types.MethodType(identity_resize,model.transform)
    if not c.get('source_only',False): model.roi_heads.box_predictor=FastRCNNPredictor(model.roi_heads.box_predictor.cls_score.in_features,nclasses+1)
    return model

def train(c,directory):
    preflight(c); seed_all(c['seed']); directory=Path(directory); directory.mkdir(parents=True,exist_ok=True)
    if c.get('source_only',False): raise ValueError('source_only is prediction-only; training a source model on evaluation data is forbidden')
    atomic_json(directory/'training_policy.json',{'final_refit':bool(c.get('final_refit',False)),'training_annotations':c['data']['train']['annotations'],'validation_during_training':False,'checkpoint_selection':'last prescribed epoch/update','updates_policy':c.get('update_policy','equal_epochs')})
    if c.get('model')=='fasterrcnn': return train_frcnn(c,directory)
    return train_ultra(c,directory)

def train_frcnn(c,d):
    import numpy as np, torch
    from torch.utils.data import DataLoader
    data=CocoDataset(c['data']['train'],c,True)
    if any(a.get('iscrowd',0) for a in data.coco['annotations']): raise ValueError('FRCNN crowd training semantics unqualified; provide crowd-free training annotations')
    model=make_frcnn(c,len(data.categories)); device=torch.device(c.get('device','cuda')); model.to(device)
    optimizer=torch.optim.SGD((p for p in model.parameters() if p.requires_grad),lr=c.get('lr',.005),momentum=.9,weight_decay=.0001)
    scheduler=torch.optim.lr_scheduler.MultiStepLR(optimizer,milestones=c.get('update_milestones',[]) if c.get('update_policy')=='equal_updates' else c.get('milestones',[8,11]),gamma=.1)
    loader=DataLoader(data,batch_size=c.get('batch_size',4),shuffle=True,num_workers=c.get('num_workers',0),collate_fn=collate,drop_last=c.get('update_policy')=='equal_updates')
    if len(loader)==0: raise ValueError('Training subset smaller than batch_size for fixed-batch equal_updates; reduce batch_size')
    checkpoint=d/'last.pt'; start=updates=exposures=0
    if checkpoint.exists() and c.get('resume',True):
        state=torch.load(checkpoint,map_location=device,weights_only=False); model.load_state_dict(state['model']); optimizer.load_state_dict(state['optimizer']); scheduler.load_state_dict(state['scheduler']); start=state['epoch']+1; updates=state['updates']; exposures=state.get('exposures',updates*c.get('batch_size',4))
        random.setstate(state['python_rng']); np.random.set_state(state['numpy_rng']); torch.set_rng_state(state['torch_rng'].cpu())
        if torch.cuda.is_available() and state.get('cuda_rng'): torch.cuda.set_rng_state_all([v.cpu() for v in state['cuda_rng']])
    begin=time.time()
    budget=c.get('max_updates') if c.get('update_policy')=='equal_updates' else None
    if budget is not None and (not isinstance(budget,int) or budget<1): raise ValueError('max_updates must be positive integer')
    if c.get('update_policy')=='equal_updates' and budget is None: raise ValueError('equal_updates requires max_updates')
    epochs=(budget+len(loader)-1)//len(loader) if budget else c.get('epochs',12)
    for epoch in range(start,epochs):
        data.epoch=epoch
        model.train(); losses=[]
        if c.get('frozen',False): model.backbone.eval()
        if budget and updates>=budget: break
        for images,targets in loader:
            optimizer.zero_grad(set_to_none=True); out=model([x.to(device) for x in images],[{k:v.to(device) for k,v in t.items() if k!='geometry'} for t in targets]); loss=sum(out.values())
            if not torch.isfinite(loss): raise RuntimeError(f'Nonfinite loss at update {updates}')
            loss.backward(); optimizer.step(); updates+=1; exposures+=len(images); losses.append(float(loss.detach()))
            if c.get('update_policy')=='equal_updates': scheduler.step()
            if budget and updates>=budget: break
        if c.get('update_policy')!='equal_updates': scheduler.step()
        state={'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scheduler':scheduler.state_dict(),'epoch':epoch,'updates':updates,'exposures':exposures,'python_rng':random.getstate(),'numpy_rng':np.random.get_state(),'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None,'categories':data.categories}
        tmp=d/'last.tmp.pt'; torch.save(state,tmp); os.replace(tmp,checkpoint)
        atomic_json(d/'progress.json',{'epoch':epoch+1,'updates':updates,'loss':sum(losses)/max(1,len(losses)),'seconds':time.time()-begin,'distinct_images':len(data.images),'repeat_exposures':exposures/len(data.images),'subset_ids':[i['id'] for i in data.images],'noise_seeds':data.noise_seeds if c.get('augmentation_bank')=='strong' else {}})
    return checkpoint

def export_yolo(spec,d):
    from .core import load_coco
    c=load_coco(spec); categories=sorted(c['categories'],key=lambda x:x['id']); mapping={x['id']:i for i,x in enumerate(categories)}
    labels=d/'labels'; images=d/'images'; labels.mkdir(parents=True,exist_ok=True); images.mkdir(exist_ok=True); anns={i['id']:[] for i in c['images']}
    for a in c['annotations']:
        if a.get('iscrowd',0): raise ValueError('YOLO export crowd semantics unsupported')
        anns[a['image_id']].append(a)
    paths=[]
    for i in c['images']:
        src=(Path(spec['image_root'])/i['file_name']).resolve(); dst=images/(str(i['id'])+src.suffix.lower())
        if not dst.exists(): dst.symlink_to(src)
        lines=[]
        for a in anns[i['id']]:
            x,y,w,h=a['bbox']; lines.append(f'{mapping[a["category_id"]]} {(x+w/2)/i["width"]:.12g} {(y+h/2)/i["height"]:.12g} {w/i["width"]:.12g} {h/i["height"]:.12g}')
        (labels/(str(i['id'])+'.txt')).write_text('\n'.join(lines)); paths.append(str(dst))
    listing=d/'images.txt'; listing.write_text('\n'.join(paths)+'\n'); return listing,[x['name'] for x in categories]

def ultra_offline_classes():
    # Set before importing the optional backend: it must not install requirements.
    os.environ['YOLO_AUTOINSTALL']='false'
    os.environ['YOLO_OFFLINE']='true'
    from ultralytics import YOLO, RTDETR
    from ultralytics.utils import downloads, checks
    from ultralytics.data import utils as data_utils
    def blocked_download(*args, **kwargs):
        raise RuntimeError('Automatic backend download blocked; provide local assets/checkpoints')
    downloads.safe_download=blocked_download
    downloads.attempt_download_asset=blocked_download
    checks.check_font=lambda *args, **kwargs: None
    data_utils.check_font=checks.check_font
    return YOLO, RTDETR

def train_ultra(c,d):
    from .backends import train_controlled
    return train_controlled(c,d)


def predict(c,d,split='test'):
    import torch
    if c.get('final_refit',False) and split=='dev': raise ValueError('final_refit includes development data; development evaluation is forbidden')
    d=Path(d); dataset=CocoDataset(c['data'][split],c,False); records=[]
    if c.get('source_only',False):
        mapping=c.get('source_category_map',{})
        if not mapping or any(int(v) not in dataset.categories for v in mapping.values()): raise ValueError('source_category_map must map native source labels to valid dataset category IDs')
    if c.get('model')=='fasterrcnn':
        model=make_frcnn(c,len(dataset.categories)); state=None if c.get('source_only',False) else torch.load(d/'last.pt',map_location='cpu',weights_only=False);
        if state is not None and state.get('categories')!=dataset.categories: raise ValueError('Checkpoint category mapping differs from prediction split')
        if state is not None: model.load_state_dict(state['model'])
        model.to(c.get('device','cuda')).eval()
        with torch.no_grad():
            for image,target in dataset:
                out=model([image.to(c.get('device','cuda'))])[0]
                for b,s,l in zip(restore_boxes(out['boxes'].cpu(),target).tolist(),out['scores'].cpu().tolist(),out['labels'].cpu().tolist()):
                    if c.get('source_only',False) and str(l) not in c['source_category_map']: continue
                    if s>=c.get('conf',.001): records.append({'image_id':int(target['image_id']),'category_id':(int(c['source_category_map'][str(l)]) if c.get('source_only',False) else dataset.categories[l-1]),'bbox':[b[0],b[1],b[2]-b[0],b[3]-b[1]],'score':s})
    else:
        YOLO,RTDETR=ultra_offline_classes()
        model=(RTDETR if c.get('model')=='rtdetr-l' else YOLO)(str(c['initial_weights'] if c.get('source_only',False) else d/'native'/'weights'/'last.pt'))
        import numpy as np
        for image,target in dataset:
            result=model.predict(image.unsqueeze(0).to(c.get('device','cuda')),conf=c.get('conf',.001),iou=c.get('nms_iou',.7),imgsz=image.shape[-1],max_det=c.get('max_det',1000),device=('0' if c.get('device','cuda')=='cuda' else c.get('device')),verbose=False)[0]
            for b,s,l in zip(restore_boxes(result.boxes.xyxy.cpu(),target).tolist(),result.boxes.conf.cpu().tolist(),result.boxes.cls.cpu().tolist()):
                if c.get('source_only',False) and str(int(l)) not in c['source_category_map']: continue
                category=int(c['source_category_map'][str(int(l))]) if c.get('source_only',False) else dataset.categories[int(l)]
                records.append({'image_id':int(target['image_id']),'category_id':category,'bbox':[b[0],b[1],b[2]-b[0],b[3]-b[1]],'score':s})
    path=d/f'predictions_{split}{c.get("_artifact_tag","")}.json'; atomic_json(path,records)
    checkpoint=Path(c['initial_weights']) if c.get('source_only',False) else d/('last.pt' if c.get('model')=='fasterrcnn' else 'native/weights/last.pt')
    atomic_json(path.with_suffix('.provenance.json'),{'checkpoint_sha256':sha256(checkpoint),'test_view':c.get('test_view','raw'),'enhancer':c.get('enhancer',{}),'enhancer_provenance':dataset.enhance.provenance,'quantization':c.get('quantization','uint8'),'conf':c.get('conf',.001),'nms_iou':c.get('nms_iou',.7),'max_det':c.get('max_det',1000),'predictions_sha256':sha256(path)})
    return path

def evaluate(c,d,split='test'):
    if c.get('final_refit',False) and split=='dev': raise ValueError('final_refit includes development data; development evaluation is forbidden')
    from pycocotools.coco import COCO
    from pycocotools.cocoeval import COCOeval
    gt=COCO(c['data'][split]['annotations']); path=Path(d)/f'predictions_{split}{c.get("_artifact_tag","")}.json'; records=json.loads(path.read_text())
    provenance=json.loads(path.with_suffix('.provenance.json').read_text())
    if provenance['predictions_sha256']!=sha256(path): raise ValueError('Predictions changed after inference')
    checkpoint=Path(c['initial_weights']) if c.get('source_only',False) else Path(d)/('last.pt' if c.get('model')=='fasterrcnn' else 'native/weights/last.pt')
    if provenance['checkpoint_sha256']!=sha256(checkpoint): raise ValueError('Checkpoint changed after inference')
    if records: dt=gt.loadRes(records)
    else:
        dt=COCO(); dt.dataset={'images':list(gt.dataset['images']),'categories':list(gt.dataset['categories']),'annotations':[]}; dt.createIndex()
    ev=COCOeval(gt,dt,'bbox'); ev.params.maxDets=[1,10,c.get('max_det',100)]; ev.evaluate(); ev.accumulate(); ev.summarize()
    # Compute all headline metrics at the actual configured detection cap.
    import numpy as np
    def average(values):
        valid=values[values>-1]
        return float(valid.mean()*100) if valid.size else None
    precision=ev.eval['precision']; recall=ev.eval['recall']
    i50=np.flatnonzero(np.isclose(ev.params.iouThrs,.5)); i75=np.flatnonzero(np.isclose(ev.params.iouThrs,.75))
    metrics={'AP':average(precision[:,:,:,0,-1]),'AP50':average(precision[i50,:,:,0,-1]),'AP75':average(precision[i75,:,:,0,-1]),'AP_small':average(precision[:,:,:,1,-1]),'AP_medium':average(precision[:,:,:,2,-1]),'AP_large':average(precision[:,:,:,3,-1]),'AR1':average(recall[:,:,0,0]),'AR10':average(recall[:,:,0,1]),'ARmax':average(recall[:,:,0,-1]),'AR_small':average(recall[:,:,1,-1]),'AR_medium':average(recall[:,:,2,-1]),'AR_large':average(recall[:,:,3,-1])}
    metrics.update({'scale':'percentage_points','split':split,'max_det':c.get('max_det',100),'predictions_sha256':sha256(path)})
    atomic_json(Path(d)/f'metrics_{split}{c.get("_artifact_tag","")}.json',metrics); return metrics

def extract_features(c,d,split='test'):
    """Save paired-image pooled and target-ROI descriptors from explicit module hooks.

    `feature_layers` contains exact named_modules() names. Saved image/object IDs
    allow analysis to join descriptors across representations without row guessing.
    Spatial tensors are average-pooled inside each GT box at feature resolution.
    """
    import numpy as np, torch
    d=Path(d); dataset=CocoDataset(c['data'][split],c,False)
    if not c.get('feature_layers'): raise ValueError('feature_layers must name explicit backbone/neck modules')
    if c['model']=='fasterrcnn':
        model=make_frcnn(c,len(dataset.categories)); state=torch.load(d/'last.pt',map_location='cpu',weights_only=False); model.load_state_dict(state['model'])
    else:
        YOLO,RTDETR=ultra_offline_classes(); model=(RTDETR if c['model']=='rtdetr-l' else YOLO)(str(d/'native'/'weights'/'last.pt')).model
    model.to(c.get('device','cuda')).eval(); modules=dict(model.named_modules()); hooks=[]; captured={}; output={}; image_ids=[]; object_ids=[]; category_ids=[]
    for name in c['feature_layers']:
        if name not in modules: raise ValueError(f'Feature module not found: {name}; available: {list(modules)}')
        def capture(module,args,value,name=name):
            # FPN dictionaries retain their explicit keys in the artifact.
            values=value if isinstance(value,dict) else ({str(i):v for i,v in enumerate(value)} if isinstance(value,(tuple,list)) else {'tensor':value})
            for key,v in values.items():
                if torch.is_tensor(v) and v.ndim==4: captured[name+'/'+str(key)]=v.detach()
        hooks.append(modules[name].register_forward_hook(capture))
    try:
        with torch.no_grad():
            for index,(image,target) in enumerate(dataset):
                captured.clear(); tensor=image.to(c.get('device','cuda')); model([tensor]) if c['model']=='fasterrcnn' else model(tensor[None])
                image_ids.append(int(target['image_id'])); annotations=dataset.anns[int(target['image_id'])]
                object_ids.extend(a['id'] for a in annotations); category_ids.extend(a['category_id'] for a in annotations)
                if not captured: raise RuntimeError('Selected feature modules produced no NCHW tensors')
                for name,value in captured.items():
                    feature=value[0]; h,w=feature.shape[-2:]; original_h,original_w=image.shape[-2:]
                    ih,iw=original_h,original_w
                    if c['model']=='fasterrcnn':
                        divisor=model.transform.size_divisible
                        ih=math.ceil(ih/divisor)*divisor; iw=math.ceil(iw/divisor)*divisor
                    valid_h=max(1,min(h,math.ceil(original_h*h/ih))); valid_w=max(1,min(w,math.ceil(original_w*w/iw)))
                    output.setdefault(name+'/global',[]).append(feature[:,:valid_h,:valid_w].mean((-2,-1)).cpu().numpy())
                    rois=output.setdefault(name+'/roi',[])
                    for box in target['boxes']:
                        x1,y1,x2,y2=box.tolist(); left=max(0,min(w-1,int(math.floor(x1*w/iw)))); top=max(0,min(h-1,int(math.floor(y1*h/ih)))); right=max(left+1,min(w,int(math.ceil(x2*w/iw)))); bottom=max(top+1,min(h,int(math.ceil(y2*h/ih))))
                        rois.append(feature[:,top:bottom,left:right].mean((-2,-1)).cpu().numpy())
    finally:
        for hook in hooks: hook.remove()
    arrays={k:np.stack(v) if v else np.empty((0,)) for k,v in output.items()}; arrays.update(image_ids=np.asarray(image_ids),object_ids=np.asarray(object_ids),category_ids=np.asarray(category_ids))
    path=d/f'features_{split}{c.get("_artifact_tag","")}.npz'; np.savez_compressed(path,**arrays)
    atomic_json(path.with_suffix('.provenance.json'),{'layers':c['feature_layers'],'test_view':c.get('test_view','raw'),'pooling':'GT-box floor/ceil grid mean with stride-padding coordinates; global mean excludes fully padded grid cells','sha256':sha256(path)})
    return path
