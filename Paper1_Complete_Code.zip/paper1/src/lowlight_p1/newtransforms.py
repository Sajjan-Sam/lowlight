"""Deterministic, geometry-preserving controls on float HWC sRGB.

Tone is global gamma matched to parent mean luminance; chroma is RGB / luminance.
Frequency swaps use a separable Gaussian with reflect boundaries, radius ceil(3σ).
These explicit operational definitions do not claim causal independence of color,
tone and texture. Clipping is applied after composition and recorded in provenance.
"""
from __future__ import annotations
import numpy as np
from .enhancers import Enhancer, validate_rgb, create_enhancer

LUMA = np.array([.299, .587, .114], dtype=np.float32)


def gaussian(image, sigma=2.0):
    x = validate_rgb(image)
    sigma = float(sigma)
    if not np.isfinite(sigma) or sigma <= 0:
        raise ValueError('sigma must be finite and positive')
    radius = int(np.ceil(3 * sigma))
    points = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-points**2 / (2 * sigma**2))
    kernel /= kernel.sum()
    out = x.astype(np.float64)
    for axis in (0, 1):
        padding = [(0, 0)] * 3
        padding[axis] = (radius, radius)
        padded = np.pad(out, padding, mode='reflect')
        windows = np.lib.stride_tricks.sliding_window_view(padded, len(kernel), axis=axis)
        out = np.einsum('...k,k->...', windows, kernel)
    return out.astype(np.float32)


class ControlTransform(Enhancer):
    def __init__(self, name, reference=None, sigma=2.0, **config):
        super().__init__(name, {'sigma': sigma, **config})
        self.reference = reference
        self.sigma = float(sigma)
        if not np.isfinite(self.sigma) or self.sigma <= 0:
            raise ValueError('sigma must be finite and positive')
        self.provenance.update({'reference': getattr(reference, 'provenance', None),
            'composition': 'Y=.299R+.587G+.114B; C=RGB/max(Y,1e-4); gamma matched t; Gaussian reflect radius ceil(3*sigma); clip [0,1]',
            'quantization': 'float32'})

    def apply(self, image):
        return self.enhance(image)

    def enhance(self, image):
        x = validate_rgb(image)
        if self.name == 'uint8':
            return (np.rint(x * 255).astype(np.uint8).astype(np.float32) / 255)
        if self.name in ('identity', 'leaveout'):
            return x.copy()
        if self.reference is None:
            raise ValueError(f'{self.name} requires reference_enhancer')
        y = validate_rgb(self.reference(x))
        if y.shape != x.shape:
            raise ValueError('Reference changed image geometry')
        if np.array_equal(x, y):
            self.last_diagnostics = {'clipped_fraction': 0., 'preclip_min': float(x.min()), 'preclip_max': float(x.max())}
            return x.copy()
        # Match the audited Y convention; avoid the general Rec709 gamma helper.
        target = float(np.mean(y @ LUMA))
        lo, hi = 1e-6, 1e6
        if target < float(np.mean(x ** hi @ LUMA)) - 1e-6 or target > float(np.mean(x ** lo @ LUMA)) + 1e-6:
            raise ValueError('Parent luminance unreachable by global gamma')
        for _ in range(80):
            mid = np.sqrt(lo * hi)
            if float(np.mean(x ** mid @ LUMA)) > target:
                lo = mid
            else:
                hi = mid
        t = (x ** np.sqrt(lo * hi)).astype(np.float32)
        yt, yy = (t @ LUMA)[..., None], (y @ LUMA)[..., None]
        ct = t / np.maximum(yt, 1e-4)
        cy = y / np.maximum(yy, 1e-4)
        if self.name == 'toneonly':
            out = t
        elif self.name == 'coloronly':
            out = yt * cy
        elif self.name == 'leavechromaout':
            out = yy * ct
        elif self.name == 'lowfrequencyswap':
            out = t + gaussian(y, self.sigma) - gaussian(t, self.sigma)
        elif self.name == 'highfrequencyswap':
            out = t + y - gaussian(y, self.sigma) - t + gaussian(t, self.sigma)
        elif self.name == 'leavehighfreqout':
            out = gaussian(y, self.sigma) + t - gaussian(t, self.sigma)
        else:
            raise ValueError(f'Unknown transform {self.name}')
        self.last_diagnostics = {'clipped_fraction': float(np.mean((out < 0) | (out > 1))),
                                 'preclip_min': float(out.min()), 'preclip_max': float(out.max())}
        return np.clip(out, 0, 1).astype(np.float32)


def build_transform(name, enhancer=None, reference=None, reference_enhancer=None, **config):
    name = name.lower().replace('_', '').replace('-', '')
    name = {"chromaswap": "coloronly", "lowfrequency": "lowfrequencyswap",
            "highfrequency": "highfrequencyswap", "leavehighfrequencyout": "leavehighfreqout"}.get(name, name)
    ref = reference or enhancer
    if reference_enhancer is not None:
        if callable(reference_enhancer):
            ref = reference_enhancer
        elif isinstance(reference_enhancer, dict):
            spec = dict(reference_enhancer)
            ref = create_enhancer(spec.pop('name'), spec)
        else:
            ref = create_enhancer(reference_enhancer, config.pop('reference_config', {}))
    if name not in ('identity', 'leaveout', 'uint8', 'toneonly', 'coloronly', 'leavechromaout', 'leavehighfreqout', 'lowfrequencyswap', 'highfrequencyswap'):
        raise ValueError(f'Unknown transform {name}')
    if ref is None and name not in ('identity', 'leaveout', 'uint8'):
        raise ValueError(f'{name} requires reference_enhancer')
    return ControlTransform(name, reference=ref, **config)
