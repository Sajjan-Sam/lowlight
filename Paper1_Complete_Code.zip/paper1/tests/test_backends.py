"""Dependency-free protocol checks plus optional tensor contract checks."""
import unittest
from lowlight_p1.data import nested_order

class SubsetTests(unittest.TestCase):
    def test_full_fraction_skips_ranking_and_saves_noise_seeds(self):
        from unittest.mock import patch
        from lowlight_p1.data import CocoDataset
        coco={'images':[{'id':1,'width':10,'height':10}],'categories':[{'id':1}], 'annotations':[]}
        with patch('lowlight_p1.data.load_coco',return_value=coco), patch('lowlight_p1.data.Enhancer'), patch('lowlight_p1.data.nested_order',side_effect=AssertionError('full-data ranking must be skipped')):
            dataset=CocoDataset({'image_root':'/unused'},{'fraction':1,'augmentation_bank':'strong'},True)
        self.assertEqual(dataset.subset_order,[1])
        self.assertIn(1,dataset.noise_seeds)
        self.assertEqual(len(dataset),12)

    def test_nested_reproducible_coverage(self):
        images=[{'id':i,'width':100,'height':100} for i in range(12)]
        anns=[{'image_id':i,'category_id':i%3,'bbox':[0,0,10+i,10]} for i in range(12)]
        order=nested_order(images,anns,7)
        self.assertEqual(order,nested_order(images,anns,7))
        self.assertEqual(set(order),set(range(12)))
        self.assertEqual(len({i%3 for i in order[:3]}),3)
        self.assertTrue(set(order[:3])<=set(order[:6]))

class RefitTests(unittest.TestCase):
    def test_refit_disallows_development_evaluation(self):
        from lowlight_p1.engine import evaluate
        with self.assertRaisesRegex(ValueError,'development evaluation is forbidden'):
            evaluate({'final_refit':True},'/unused','dev')

class TensorTests(unittest.TestCase):
    def test_batch_and_geometry_roundtrip(self):
        try: import torch
        except ImportError: self.skipTest('torch is not installed; tensor backend is not qualified here')
        from lowlight_p1.backends import ultra_batch
        from lowlight_p1.data import restore_boxes
        target={'boxes':torch.tensor([[12.,24.,32.,64.]]),'labels':torch.tensor([1]),'geometry':torch.tensor([2.,2.,2.,4.,50.,50.])}
        restored=restore_boxes(target['boxes'],target)
        self.assertTrue(torch.equal(restored,torch.tensor([[5.,10.,15.,30.]])))
        batch=ultra_batch([torch.zeros(3,100,100)],[target],'cpu')
        self.assertTrue(torch.allclose(batch['bboxes'],torch.tensor([[.22,.44,.2,.4]])))
        self.assertEqual(batch['cls'].tolist(),[[0.]])

if __name__=='__main__': unittest.main()
