import importlib.util
import unittest
import tempfile
from pathlib import Path
import numpy as np
from lowlight_p1.analysis import box_iou, matched_objects, matched_deltas, linear_cka, rbf_mmd, coco_metrics, paired_feature_analysis
GT={'images':[{'id':1,'width':100,'height':100}],'categories':[{'id':1,'name':'x'}],'annotations':[{'id':1,'image_id':1,'category_id':1,'bbox':[0,0,10,10],'area':100,'iscrowd':0}]}
P=[{'image_id':1,'category_id':1,'bbox':[0,0,10,10],'score':.9}]

class AnalysisTests(unittest.TestCase):
    def test_iou_and_unique_match(self):
        self.assertEqual(box_iou([0,0,10,10],[0,0,10,10]),1)
        g=dict(GT,annotations=GT['annotations']+[dict(GT['annotations'][0],id=2)])
        self.assertEqual(sum(x['matched'] for x in matched_objects(g,P)),1)
    def test_deltas_unmatched_not_artificial_confidence(self):
        row=matched_deltas(GT,[],P)[0]
        self.assertEqual(row['recall_delta'],1); self.assertIsNone(row['confidence_delta']); self.assertIsNone(row['iou_delta'])
        row=matched_deltas(GT,P,[dict(P[0],score=.8)])[0]
        self.assertAlmostEqual(row['confidence_delta'],-.1); self.assertEqual(row['iou_delta'],0)
    def test_feature_metrics(self):
        x=np.arange(12).reshape(4,3)
        self.assertAlmostEqual(linear_cka(x,x*3+7),1)
        self.assertTrue(np.isfinite(rbf_mmd(x,x,2)))
        with self.assertRaises(ValueError): linear_cka(np.ones((3,2)),np.ones((3,2)))
    def test_backend_feature_join(self):
        with tempfile.TemporaryDirectory() as directory:
            a=Path(directory)/'a.npz'; b=Path(directory)/'b.npz'
            x=np.arange(12).reshape(4,3)
            np.savez(a,object_ids=[10,20,30,40],category_ids=[1]*4,**{'neck/roi':x})
            np.savez(b,object_ids=[40,30,20,10],category_ids=[1]*4,**{'neck/roi':(x*3+2)[::-1]})
            rows=paired_feature_analysis(a,b,2)
            self.assertAlmostEqual(rows[0]['linear_CKA'],1)
            np.savez(b,object_ids=[1,2,3,4],category_ids=[1]*4,**{'neck/roi':x})
            with self.assertRaises(ValueError): paired_feature_analysis(a,b,2)
    @unittest.skipUnless(importlib.util.find_spec('pycocotools'),'pycocotools absent; no AP claim')
    def test_actual_coco_known_perfect_and_empty(self):
        self.assertAlmostEqual(coco_metrics(GT,P)['AP'],100)
        self.assertEqual(coco_metrics(GT,[])['AP'],0)

if __name__=='__main__': unittest.main()
