#!/usr/bin/env bash
# Dependency-free wrapper regression checks; no scheduler or GPU required.
set -euo pipefail
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
tmp=$(mktemp -d)
trap 'rm -rf -- "$tmp"' EXIT
mkdir -p "$tmp/bin" "$tmp/input with spaces"
cat > "$tmp/bin/python" <<'PY'
#!/usr/bin/env bash
if [[ "${1:-}" == - ]]; then
  printf '2\n'
else
  printf '%s\n' "$@" > "$CAPTURE"
fi
PY
cat > "$tmp/bin/sbatch" <<'SH'
#!/usr/bin/env bash
printf '%s\n' "$@" > "$SBATCH_CAPTURE"
SH
chmod +x "$tmp/bin/"*
export PATH="$tmp/bin:$PATH" CAPTURE="$tmp/python_args" SBATCH_CAPTURE="$tmp/sbatch_args"
manifest="$tmp/input with spaces/manifest.csv"
config="$tmp/input with spaces/config.json"
printf 'run_id\nfirst\nsecond\n' > "$manifest"
printf '{}\n' > "$config"
bash "$repo/paper1/scripts/submit_array.sh" --manifest "$manifest" --config "$config" --output-root "$tmp/log root" --dry-run > "$tmp/command"
[[ ! -e "$tmp/log root" && ! -e "$SBATCH_CAPTURE" ]]
grep -q -- '--validate-only' "$CAPTURE"
grep -q -- '--array=0-1%1' "$tmp/command"
bash "$repo/paper1/scripts/submit_array.sh" --manifest "$manifest" --config "$config" --output-root "$tmp/log root" > /dev/null
[[ -d "$tmp/log root/slurm_logs" ]]
[[ $(tail -n 4 "$SBATCH_CAPTURE" | head -n 1) == "$manifest" ]]
[[ $(tail -n 3 "$SBATCH_CAPTURE" | head -n 1) == "$config" ]]
if bash "$repo/paper1/scripts/submit_array.sh" --manifest "$manifest" --config "$config" --cpus 0 --dry-run > /dev/null 2>&1; then exit 1; fi
if SLURM_ARRAY_TASK_ID=bad bash "$repo/paper1/scripts/array_task.sh" "$manifest" "$config" > /dev/null 2>&1; then exit 1; fi
SLURM_ARRAY_TASK_ID=1 bash "$repo/paper1/scripts/array_task.sh" "$manifest" "$config"
grep -q -- '--row-index' "$CAPTURE"
grep -q -- '--stage' "$CAPTURE"
[[ $(tail -n 1 "$CAPTURE") == train ]]
bash "$repo/paper1/scripts/workflow.sh" plan --config "$config" --profile full --output "$tmp/full.csv"
grep -q -- 'plan' "$CAPTURE"
grep -q -- '--profile' "$CAPTURE"
bash "$repo/paper1/scripts/workflow.sh" evaluate --config "$config" --manifest "$manifest" --split dev
grep -q -- 'study-evaluate' "$CAPTURE"
printf 'SLURM wrapper checks passed\n'
