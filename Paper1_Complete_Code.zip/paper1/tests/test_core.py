import copy
import json
from pathlib import Path
import tempfile
import unittest
from PIL import Image
from lowlight_p1.core import atomic_json, load_coco, validate_data
from lowlight_p1.cli import check_config, manifest_configs, execute, training_provenance

class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.config={'run_id':'unit','output_root':str(self.root/'runs'),'seed':0,'model':'fasterrcnn','data':{}}
        for n,split in enumerate(('train','dev','test')):
            image=self.root/f'{split}.png'; Image.new('RGB',(4,3),(n*50,30,20)).save(image)
            spec={'image_root':str(self.root),'annotations':str(self.root/f'{split}.json')}
            atomic_json(spec['annotations'],{'images':[{'id':1,'file_name':image.name,'width':4,'height':3}],'categories':[{'id':7,'name':'object'}],'annotations':[{'id':1,'image_id':1,'category_id':7,'bbox':[0,0,2,2],'area':4,'iscrowd':0}]})
            self.config['data'][split]=spec
    def tearDown(self): self.temp.cleanup()
    def test_validate_and_leakage(self):
        self.assertEqual(validate_data(self.config)['train']['objects'],1)
        (self.root/'test.png').write_bytes((self.root/'train.png').read_bytes())
        with self.assertRaisesRegex(ValueError,'leakage'): validate_data(self.config)
    def test_invalid_geometry_and_escape(self):
        spec=self.config['data']['train']; c=json.loads(Path(spec['annotations']).read_text()); c['annotations'][0]['bbox']=[3,0,2,2]; atomic_json(spec['annotations'],c)
        with self.assertRaisesRegex(ValueError,'Invalid box'): load_coco(spec)
        c['annotations']=[]; c['images'][0]['file_name']='../escape.png'; atomic_json(spec['annotations'],c)
        with self.assertRaisesRegex(ValueError,'escapes'): load_coco(spec,False)
    def test_manifest_merge_and_duplicate(self):
        p=self.root/'matrix.csv'; p.write_text('run_id,seed,enhancer.name,protocol,update_policy,max_updates\na,3,gamma,exact_six_view,equal_updates,12\n')
        row=manifest_configs(p,self.config)[0]; self.assertEqual(row['seed'],3); self.assertEqual(row['enhancer']['name'],'gamma')
        p.write_text('run_id\na\na\n')
        with self.assertRaisesRegex(ValueError,'Duplicate'): manifest_configs(p,self.config)
    def test_run_identity_and_status(self):
        d=execute('validate-data',self.config)
        self.assertEqual(json.loads((d/'status.json').read_text())['state'],'complete')
        changed=copy.deepcopy(self.config); changed['seed']=1
        with self.assertRaisesRegex(ValueError,'different configuration'): execute('validate-data',changed)
    def test_provenance_detects_checkpoint_content_changes(self):
        weights=self.root/'weights.pt'; weights.write_bytes(b'original')
        c={**self.config,'initial_weights':str(weights)}
        before=training_provenance(c)
        weights.write_bytes(b'changed')
        self.assertNotEqual(before['initial_weights_sha256'],training_provenance(c)['initial_weights_sha256'])
        self.assertIn('engine.py',before['runner_source_sha256'])
    def test_dataset_mutation_rejected_before_overwrite(self):
        d=execute('validate-data',self.config)
        before=(d/'data_validation.json').read_bytes()
        Image.new('RGB',(4,3),(9,8,7)).save(self.root/'train.png')
        with self.assertRaisesRegex(ValueError,'contents changed'): execute('validate-data',self.config)
        self.assertEqual((d/'data_validation.json').read_bytes(),before)
    def test_unsupported_protocol_fails_closed(self):
        c={**self.config,'model':'yolov8n','protocol':'exact_six_view'}
        self.assertEqual(check_config(c)['protocol'],'exact_six_view')
        with self.assertRaisesRegex(ValueError,'Unknown protocol'): check_config({**c,'protocol':'invalid'})
    def test_update_budget_required(self):
        with self.assertRaisesRegex(ValueError,'max_updates'): check_config({**self.config,'update_policy':'equal_updates'})

if __name__=='__main__': unittest.main()

class ManifestFileTests(unittest.TestCase):
    def test_config_path_manifest(self):
        import tempfile
        from lowlight_p1.core import atomic_json
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            atomic_json(root/'run.json',{'run_id':'x','model':'yolov8n','protocol':'exact_six_view'})
            (root/'matrix.csv').write_text('run_id,config_path\nx,run.json\n')
            rows=manifest_configs(root/'matrix.csv',{'datasets':{}})
            self.assertEqual(rows[0]['run_id'],'x')
            self.assertNotIn('datasets',rows[0])
