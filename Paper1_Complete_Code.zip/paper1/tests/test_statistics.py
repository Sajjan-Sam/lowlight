import unittest
from lowlight_p1.statistics import resample_coco, paired_bootstrap, paired_permutation, holm

GT={'images':[{'id':10,'scene':'a'},{'id':20,'scene':'b'}],'categories':[{'id':1,'name':'x'}],'annotations':[{'id':7,'image_id':10,'category_id':1,'bbox':[0,0,1,1]}]}
A=[{'image_id':10,'score':1}]
B=[{'image_id':10,'score':2},{'image_id':20,'score':2}]
def metric(g,p): return sum(x['score'] for x in p)/len(g['images'])

class StatisticsTests(unittest.TestCase):
    def test_duplicate_draw_renumbers_all(self):
        g,p=resample_coco(GT,A,[10,10,20])
        self.assertEqual([x['id'] for x in g['images']],[1,2,3])
        self.assertEqual([x['image_id'] for x in g['annotations']],[1,2])
        self.assertEqual([x['id'] for x in g['annotations']],[1,2])
        self.assertEqual([x['image_id'] for x in p],[1,2])
        self.assertEqual(GT['images'][0]['id'],10)
    def test_seed_metric_mean_not_ensemble(self):
        result=paired_bootstrap(GT,[A,A],[B,B],metric,n_boot=20,seed=2)
        self.assertEqual(result['difference'],1.5)
        self.assertTrue(set(result['draws'])<={1.,1.5,2.})
    def test_global_metric_recomputed_and_seeds_not_pooled(self):
        # Squaring dataset mean distinguishes recomputation from image averaging
        # and averaging seed metrics from prediction ensembling.
        nonlinear=lambda g,p: metric(g,p)**2
        r=paired_bootstrap(GT,[A,A],[B,[]],nonlinear,n_boot=30,seed=3)
        self.assertEqual(r['difference'],1.75)
        self.assertTrue(set(r['draws'])<={1.,1.75,2.})

    def test_paired_identity_null(self):
        result=paired_permutation(GT,[B],[B],metric,n_perm=19)
        self.assertEqual(result['p_value'],1)
        boot=paired_bootstrap(GT,[B],[B],metric,n_boot=10)
        self.assertEqual(boot['draws'],[0]*10)
    def test_scene_clusters(self):
        g=dict(GT,images=[{'id':10,'scene':'a'},{'id':20,'scene':'a'}])
        r=paired_bootstrap(g,[A],[B],metric,n_boot=10,cluster_key='scene')
        self.assertEqual(r['n_clusters'],1); self.assertEqual(r['draws'],[1.5]*10)
    def test_holm(self):
        self.assertEqual(holm([.03,.01,.04]),[.06,.03,.06])
        with self.assertRaises(ValueError): holm([float('nan')])

if __name__=='__main__': unittest.main()
