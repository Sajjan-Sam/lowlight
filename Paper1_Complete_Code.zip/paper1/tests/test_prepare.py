import json
from pathlib import Path
import tempfile
import unittest
from PIL import Image
from lowlight_p1.prepare import prepare

class PrepareTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.base=Path(self.tmp.name)
        self.images=self.base/'images'; self.labels=self.base/'labels'
        self.images.mkdir(); self.labels.mkdir()
        for i in range(5): Image.new('RGB',(12,10),(i*30,10,20)).save(self.images/f'{i}.png')
        self.train=self.base/'train.txt'; self.test=self.base/'test.txt'
        self.train.write_text('0.png\n1.png\n2.png\n3.png\n'); self.test.write_text('4.png\n')
        self.config=dict(image_root=str(self.images),annotation_root=str(self.labels),output_root=str(self.base/'prepared'),train_list=str(self.train),test_list=str(self.test),dev_fraction=.25,seed=11)
    def tearDown(self): self.tmp.cleanup()
    def read(self,result,split): return json.loads(Path(result['data'][split]['annotations']).read_text())
    def test_darkface_and_reproducibility(self):
        for i in range(5): (self.labels/f'{i}.txt').write_text('1\n0 0 11 9\n')
        c=dict(self.config,dataset='darkface'); first=prepare(c)
        self.assertEqual(self.read(first,'test')['annotations'][0]['bbox'],[0,0,12,10])
        before=Path(first['manifest']).read_text(); prepare(c)
        self.assertEqual(before,Path(first['manifest']).read_text())
        sets=[{i['file_name'] for i in self.read(first,s)['images']} for s in ('train','dev','test')]
        self.assertFalse(sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])
        (self.labels/'4.txt').write_text('2\n0 0 11 9\n')
        with self.assertRaisesRegex(ValueError,'count mismatch'): prepare(c)
    def test_exdark(self):
        listing=self.base/'classes.txt'
        listing.write_text('\n'.join(f'{i}.png 1 4 {3 if i==4 else 1}' for i in range(5)))
        for i in range(5): (self.labels/f'{i}.png.txt').write_text('% bbGt version=3\nBicycle 1 1 12 10 0 0 0 0 0 0\n')
        result=prepare(dict(self.config,dataset='exdark',class_list=str(listing)))
        image=self.read(result,'test')['images'][0]
        self.assertEqual(image['lighting'],'4'); self.assertEqual(self.read(result,'test')['annotations'][0]['bbox'],[0,0,12,10])
    def test_voc(self):
        for i in range(5):
            (self.labels/f'{i}.xml').write_text('<annotation><size><width>12</width><height>10</height></size><object><name>car</name><bndbox><xmin>1</xmin><ymin>1</ymin><xmax>12</xmax><ymax>10</ymax></bndbox></object></annotation>')
        result=prepare(dict(self.config,dataset='maet'))
        self.assertEqual(self.read(result,'test')['annotations'][0]['bbox'],[0,0,12,10])
    def test_nod_metadata(self):
        paths={}
        for split,indices in [('train',range(4)),('test',[4])]:
            path=self.base/(split+'.json'); paths[split+'_annotations']=str(path)
            path.write_text(json.dumps(dict(images=[dict(id=i,file_name=f'{i}.png',width=12,height=10,camera='Sony',lighting='extreme') for i in indices],annotations=[],categories=[dict(id=7,name='car')])))
        result=prepare(dict(self.config,dataset='nod',**paths))
        self.assertEqual(self.read(result,'test')['images'][0]['camera'],'Sony')
        self.assertEqual(self.read(result,'test')['categories'][0]['id'],7)
    def test_paths_exif_and_invalid_boxes(self):
        for i in range(5): (self.labels/f'{i}.txt').write_text('1\n0 0 11 9\n')
        c=dict(self.config,dataset='darkface')
        self.train.write_text('../0.png\n1.png\n')
        with self.assertRaisesRegex(ValueError,'Unsafe'): prepare(c)
        self.train.write_text('0.png\n1.png\n2.png\n3.png\n')
        (self.labels/'4.txt').write_text('1\n0 0 12 9\n')
        with self.assertRaisesRegex(ValueError,'Invalid box'): prepare(c)
        (self.labels/'4.txt').write_text('1\n0 0 11 9\n')
        exif=Image.Exif(); exif[274]=6
        Image.new('RGB',(12,10)).save(self.images/'4.png',exif=exif)
        with self.assertRaisesRegex(ValueError,'EXIF'): prepare(c)

if __name__=='__main__': unittest.main()

class PartitionTests(PrepareTests):
    def test_train_all_union_excludes_test(self):
        for i in range(5): (self.labels/f'{i}.txt').write_text('1\n0 0 11 9\n')
        result = prepare(dict(self.config,dataset='darkface'))
        self.assertEqual(set(result['data']), {'train','dev','test'})
        union = json.loads(Path(result['train_all']['annotations']).read_text())
        names = {i['file_name'] for i in union['images']}
        train_dev = {i['file_name'] for split in ('train','dev') for i in self.read(result,split)['images']}
        test = {i['file_name'] for i in self.read(result,'test')['images']}
        self.assertEqual(names, train_dev)
        self.assertFalse(names & test)
        self.assertEqual(len(union['annotations']), 4)
        self.assertEqual(len({a['id'] for a in union['annotations']}), 4)
        manifest = json.loads(Path(result['manifest']).read_text())
        self.assertEqual(manifest['train_all'],result['train_all'])
        self.assertEqual(manifest['train_all_validation']['images'],4)

    def test_duplicate_content_and_ambiguity(self):
        for i in range(5): (self.labels/f'{i}.txt').write_text('0\n')
        c=dict(self.config,dataset='darkface')
        (self.images/'4.png').write_bytes((self.images/'0.png').read_bytes())
        with self.assertRaisesRegex(ValueError,'leakage'): prepare(c)
        for directory in ('a','b'):
            (self.images/directory).mkdir()
            Image.new('RGB',(12,10)).save(self.images/directory/'unknown.png')
        self.train.write_text('unknown.png\n1.png\n')
        with self.assertRaisesRegex(ValueError,'ambiguous'): prepare(c)
