"""Control/cache checks run without torch; learned-contract checks require torch."""
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from lowlight_p1.enhancers import (BrightnessMatchedGamma, LearnedEnhancer,
                                   cached_enhance, create_enhancer, validate_rgb)


class Controls(unittest.TestCase):
    def test_rgb_and_identity(self):
        x = np.full((3, 5, 3), .25, np.float32)
        y = create_enhancer('raw')(x)
        np.testing.assert_array_equal(y, x)
        self.assertFalse(np.shares_memory(x, y))
        for bad in (x.astype(np.uint8), x[..., 0], x * np.nan, x + 1):
            with self.assertRaises(ValueError):
                validate_rgb(bad)

    def test_gamma_match_and_unreachable(self):
        x = np.full((3, 5, 3), .25, np.float32)
        np.testing.assert_allclose(BrightnessMatchedGamma(.5)(x), .5, atol=1e-6)
        with self.assertRaises(ValueError):
            BrightnessMatchedGamma(.1)(np.zeros_like(x))

    def test_cache_includes_matched_target_and_input(self):
        x = np.full((3, 5, 3), .25, np.float32)
        with tempfile.TemporaryDirectory() as d:
            a = cached_enhance(BrightnessMatchedGamma(.5), x, d)
            b = cached_enhance(BrightnessMatchedGamma(.7), x, d)
            self.assertEqual(len(list(Path(d).glob('*.npy'))), 2)
            np.testing.assert_allclose(a, .5, atol=1e-6)
            np.testing.assert_allclose(b, .7, atol=1e-6)
            cached_enhance(BrightnessMatchedGamma(.7), x * .5, d)
            self.assertEqual(len(list(Path(d).glob('*.npy'))), 3)
            for p in Path(d).glob('*.npy'):
                p.write_bytes(b'corrupt')
            with self.assertRaises(ValueError):
                cached_enhance(BrightnessMatchedGamma(.5), x, d)

    def test_cache_rejects_valid_npy_tampering(self):
        x = np.full((3, 4, 3), .25, np.float32)
        with tempfile.TemporaryDirectory() as d:
            cached_enhance(create_enhancer('raw'), x, d)
            np.save(next(Path(d).glob('*.npy')), x + .1)
            with self.assertRaisesRegex(ValueError, 'checksum'):
                cached_enhance(create_enhancer('raw'), x, d)

    def test_missing_weights_never_fall_back(self):
        for name in ('sci', 'zerodcepp', 'pairlie', 'retinexformer'):
            with self.assertRaises(FileNotFoundError):
                create_enhancer(name)


@unittest.skipUnless(importlib.util.find_spec('torch'), 'torch is not installed')
class LearnedContracts(unittest.TestCase):
    def run_contract(self, name, forward, multiple=1):
        import torch
        class Model(torch.nn.Module):
            def forward(self, t):
                return forward(t)
        # Exercise the inference boundary without external code or checkpoints.
        adapter = object.__new__(LearnedEnhancer)
        adapter.device = torch.device('cpu')
        adapter.model = Model().eval()
        adapter.multiple = multiple
        adapter.output_contract = {'sci':'sci_ir', 'zerodcepp':'zerodcepp_pair',
                                   'pairlie':'pairlie_lrx', 'retinexformer':'tensor'}[name]
        x = np.full((3, 5, 3), .25, np.float32)
        return adapter, x, adapter(x)

    def test_sci_uses_reflectance(self):
        _, _, y = self.run_contract('sci', lambda t: (t * 0 + .1, t * 0 + .8))
        np.testing.assert_allclose(y, .8)

    def test_zerodcepp_uses_final_image_not_curve(self):
        _, _, y = self.run_contract('zerodcepp', lambda t: (t * 0 + .8, t * 0 - .2))
        np.testing.assert_allclose(y, .8)

    def test_pairlie_composes_illumination_and_reflectance(self):
        _, _, y = self.run_contract('pairlie', lambda t: (t[:, :1] * 0 + .25, t * 0 + .6, t))
        np.testing.assert_allclose(y, .25 ** .2 * .6, rtol=1e-6)

    def test_padding_preserves_geometry_and_pixels(self):
        adapter, x, y = self.run_contract('retinexformer', lambda t: t, 12)
        np.testing.assert_array_equal(x, y)
        with self.assertRaises(ValueError):
            adapter(x[:1])

    def test_invalid_output_geometry_and_values_fail(self):
        import torch
        for result in (lambda t: t[..., :-1], lambda t: t * torch.nan):
            with self.assertRaises(ValueError):
                self.run_contract('retinexformer', result)


if __name__ == '__main__':
    unittest.main()
