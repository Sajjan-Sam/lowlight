import csv
import json
import tempfile
import unittest
from pathlib import Path
from lowlight_p1.study import plan, status, GROUP_COUNTS

class StudyTests(unittest.TestCase):
    def project(self,root):
        return {'work_root':str(root/'runs'),'epochs':2,'batch_size':2,'max_updates':{'exdark':12,'darkface':18},
                'weights':{m:str(root/(m+'.pt')) for m in ('yolov8n','yolov8s','yolov8m','fasterrcnn','rtdetr-l')},
                'enhancers':{e:{'name':n} for e,n in [('SCI','sci'),('RF','retinexformer'),('ZD','zerodcepp'),('PL','pairlie')]},
                'datasets':{d:{'data':{s:{'annotations':str(root/d/(s+'.json')),'image_root':str(root/d)} for s in ('train','dev','test')}} for d in ('exdark','darkface','nod')}}
    def test_full_counts_and_pilot_reuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); p=self.project(root)
            full=plan(p,'full',root/'full.csv'); pilot=plan(p,'pilot',root/'pilot.csv')
            self.assertEqual(full['trainings'],453); self.assertEqual(pilot['trainings'],10)
            self.assertEqual(full['groups'],{'P1-'+k:v for k,v in GROUP_COUNTS.items()})
            def configs(name):
                with (root/name).open() as f: rows=list(csv.DictReader(f))
                return {r['run_id']:json.loads(Path(r['config_path']).read_text()) for r in rows}
            all_=configs('full.csv'); small=configs('pilot.csv')
            for key,c in small.items(): self.assertEqual(c,all_[key])
            self.assertEqual(len(all_),453)
            frozen=[c for c in all_.values() if c['group']=='P1-F']
            self.assertTrue(all(c['frozen'] and c['update_policy']=='equal_updates' for c in frozen))
            self.assertEqual({c['fraction'] for c in frozen},{.1,.25,.5,1.})
            self.assertEqual(status(p,root/'pilot.csv')['counts'],{'pending':10})
            self.assertEqual(plan(p,'full',root/'full.csv'),full)
            p['epochs']=3
            with self.assertRaises(ValueError): plan(p,'full',root/'full.csv')
    def test_missing_budget_does_not_invent_counts(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); p=self.project(root); del p['max_updates']
            with self.assertRaisesRegex(ValueError,'prepared'): plan(p,'full',root/'full.csv')
            self.assertFalse((root/'full.csv').exists())
if __name__=='__main__': unittest.main()
