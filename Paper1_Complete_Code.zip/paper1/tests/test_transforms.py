import unittest
import numpy as np
from lowlight_p1.newtransforms import gaussian, build_transform
from lowlight_p1.enhancers import create_enhancer

class Transforms(unittest.TestCase):
    def test_gaussian_preserves_constant_and_channels(self):
        x = np.full((7, 5, 3), .3, np.float32)
        np.testing.assert_allclose(gaussian(x), x, atol=1e-7)
        x[..., 1:] = 0
        self.assertFalse(gaussian(x)[..., 1:].any())

    def test_identical_reference_swaps_are_identity(self):
        x = np.random.default_rng(2).uniform(.2, .8, (9, 7, 3)).astype(np.float32)
        for name in ('tone_only', 'color_only', 'low_frequency_swap', 'high_frequency_swap'):
            np.testing.assert_allclose(build_transform(name, reference=create_enhancer('raw'))(x), x, atol=1e-7)

    def test_tone_and_color_operational_definition(self):
        x = np.full((4, 6, 3), .2, np.float32)
        ref = create_enhancer('gamma', gamma=.5)
        np.testing.assert_allclose(build_transform('tone_only', reference=ref)(x), np.sqrt(x), atol=1e-6)
        np.testing.assert_allclose(build_transform('color_only', reference=ref)(x), np.sqrt(x), atol=1e-6)

    def test_uint8_explicit_quantization(self):
        x = np.full((2, 3, 3), .1234, np.float32)
        y = build_transform('uint8')(x)
        np.testing.assert_allclose(y * 255, np.rint(x * 255), atol=1e-6)
        self.assertEqual(y.dtype, np.float32)

    def test_fail_closed_reference_and_sigma(self):
        with self.assertRaises(ValueError): build_transform('tone_only')
        with self.assertRaises(ValueError): build_transform('identity', sigma=0)

    def test_all_six_formulas_against_explicit_construction(self):
        from lowlight_p1.newtransforms import LUMA
        from lowlight_p1.enhancers import BrightnessMatchedGamma
        x = np.random.default_rng(8).uniform(.15, .65, (8, 6, 3)).astype(np.float32)
        y = np.clip(x * np.array([1.3, .9, 1.1], np.float32), 0, 1)
        t = BrightnessMatchedGamma().enhance(x, reference=y)
        yt, yy = (t @ LUMA)[..., None], (y @ LUMA)[..., None]
        lt, ly = gaussian(t, 2), gaussian(y, 2)
        expected = {'tone-only': t, 'chroma-swap': yt * y / np.maximum(yy, 1e-4),
                    'low-frequency': t + ly - lt,
                    'high-frequency': t + (y - ly) - (t - lt),
                    'leave-chroma-out': yy * t / np.maximum(yt, 1e-4),
                    'leave-high-frequency-out': ly + t - lt}
        for name, result in expected.items():
            transform = build_transform(name, reference=lambda z: y)
            np.testing.assert_allclose(transform(x), np.clip(result, 0, 1), atol=5e-7)
            self.assertIn('clipped_fraction', transform.last_diagnostics)
