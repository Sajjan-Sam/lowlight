#!/usr/bin/env bash
set -euo pipefail
usage() { echo 'Usage: submit_array.sh --manifest FILE --config FILE [--partition NAME] [--account NAME] [--gpus N] [--cpus N] [--memory SIZE] [--time HH:MM:SS] [--max-concurrent N] [--activate-script FILE] [--output-root DIR] [--stage train|predict|evaluate|run] [--dry-run]'; }
manifest= config= partition= account= activate= dry=0 stage=train
output_root=/nfs/nas/samiran1/Sajjan/lowlight_paper1_runs
gpus=1 cpus=8 memory=32G walltime=12:00:00 concurrent=1
while (($#)); do
  case "$1" in
    --dry-run) dry=1; shift;;
    --manifest|--config|--partition|--account|--gpus|--cpus|--memory|--time|--max-concurrent|--activate-script|--output-root|--stage)
      (($# >= 2)) || { usage >&2; exit 2; }
      case "$1" in
        --stage) stage=$2;; --manifest) manifest=$2;; --config) config=$2;; --partition) partition=$2;; --account) account=$2;;
        --gpus) gpus=$2;; --cpus) cpus=$2;; --memory) memory=$2;; --time) walltime=$2;;
        --max-concurrent) concurrent=$2;; --activate-script) activate=$2;; --output-root) output_root=$2;;
      esac; shift 2;;
    --help) usage; exit 0;; *) usage >&2; exit 2;;
  esac
done
case "$stage" in train|predict|evaluate|run) ;; *) echo "Invalid stage: $stage" >&2; exit 2;; esac
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
[[ -f "$repo/paper1/src/lowlight_p1/__main__.py" ]] || { echo 'Invalid repository working directory' >&2; exit 2; }
[[ -f "$manifest" && -f "$config" ]] || { echo 'Manifest and config must be existing files' >&2; exit 2; }
[[ -z "$activate" || -f "$activate" ]] || { echo 'Activation script does not exist' >&2; exit 2; }
for number in "$gpus" "$cpus" "$concurrent"; do [[ "$number" =~ ^[1-9][0-9]*$ ]] || { echo 'Resource counts must be positive integers' >&2; exit 2; }; done
manifest=$(realpath -- "$manifest"); config=$(realpath -- "$config")
output_root=$(realpath -m -- "$output_root")
export PYTHONPATH="$repo/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
# Resolve every row and reject unsupported requests before scheduling work.
python -m lowlight_p1 manifest --manifest "$manifest" --config "$config" --stage "$stage" --validate-only >&2
[[ -z "$activate" ]] || activate=$(realpath -- "$activate")
# CSV parser counts records, including quoted fields, without assuming line count.
rows=$(python - "$manifest" <<'PY'
import csv, sys
with open(sys.argv[1], newline='') as stream:
    reader = csv.DictReader(stream)
    if not reader.fieldnames: raise SystemExit('Manifest has no header')
    rows = list(reader)
    if not rows: raise SystemExit('Manifest has no rows')
    print(len(rows))
PY
)
log_dir="$output_root/slurm_logs"
args=(sbatch --job-name=paper1 --chdir="$repo" --array="0-$((rows-1))%$concurrent" --gres="gpu:$gpus" --cpus-per-task="$cpus" --mem="$memory" --time="$walltime" --output="$log_dir/%A_%a.out" --error="$log_dir/%A_%a.err")
[[ -z "$partition" ]] || args+=(--partition="$partition")
[[ -z "$account" ]] || args+=(--account="$account")
args+=("$repo/paper1/scripts/array_task.sh" "$manifest" "$config" "$activate" "$stage")
if ((dry)); then printf '%q ' "${args[@]}"; printf '\n'; exit 0; fi
command -v sbatch >/dev/null || { echo 'sbatch unavailable; use --dry-run locally' >&2; exit 2; }
mkdir -p -- "$log_dir"
"${args[@]}"
