#!/usr/bin/env bash
set -euo pipefail
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
export PYTHONPATH="$repo/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
if [[ $# -gt 0 ]]; then
  exec python -m lowlight_p1 doctor "$@"
fi
python - <<'PY'
import importlib, os, sys
print('Python:', sys.version.split()[0], sys.executable)
failed = []
for name in ('torch', 'torchvision', 'numpy', 'PIL', 'pycocotools', 'ultralytics', 'lowlight_p1'):
    try:
        module = importlib.import_module(name)
        print(name, getattr(module, '__version__', 'importable'))
    except Exception as exc:
        failed.append(name)
        print(name, 'UNAVAILABLE:', str(exc))
try:
    import torch
    print('CUDA available:', torch.cuda.is_available())
    if torch.cuda.is_available(): print('GPU:', torch.cuda.get_device_name(0))
except ImportError: pass
for path in ('/nfs/nas/samiran1/Sajjan/Dataset', '/nfs/nas/samiran1/Sajjan/lowlight_paper1_runs'):
    print(path, 'exists:', os.path.isdir(path))
if failed: raise SystemExit('Missing/unusable dependencies: ' + ', '.join(failed))
PY
