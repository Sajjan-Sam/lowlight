#!/usr/bin/env bash
set -euo pipefail
[[ $# -ge 2 && $# -le 4 ]] || { echo 'Usage: array_task.sh MANIFEST CONFIG [ACTIVATION_SCRIPT] [STAGE]' >&2; exit 2; }
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
cd -- "$repo"
[[ -f paper1/src/lowlight_p1/__main__.py ]] || { echo 'Invalid repository working directory' >&2; exit 2; }
[[ "${SLURM_ARRAY_TASK_ID:-}" =~ ^[0-9]+$ ]] || { echo 'SLURM_ARRAY_TASK_ID must be a zero-based integer' >&2; exit 2; }
[[ -z "${3:-}" ]] || source "$3"
export PYTHONPATH="$repo/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
stage=${4:-train}
case "$stage" in train|predict|evaluate|run) ;; *) echo "Invalid stage" >&2; exit 2;; esac
exec python -m lowlight_p1 manifest --manifest "$1" --row-index "$SLURM_ARRAY_TASK_ID" --config "$2" --stage "$stage"
