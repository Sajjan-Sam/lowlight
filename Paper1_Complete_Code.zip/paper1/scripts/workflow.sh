#!/usr/bin/env bash
# Stage driver. Uses the already activated environment; installs nothing.
set -euo pipefail
repo=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd -P)
export PYTHONPATH="$repo/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
usage() { echo 'Usage: workflow.sh prepare|plan|doctor|submit|status|evaluate|analyze --config PROJECT.json [stage arguments]'; }
[[ $# -ge 1 ]] || { usage >&2; exit 2; }
stage=$1; shift
case "$stage" in
 prepare|plan|doctor|status|analyze) exec python -m lowlight_p1 "$stage" "$@";;
 submit) exec bash "$repo/paper1/scripts/submit_array.sh" "$@";;
 evaluate) exec python -m lowlight_p1 study-evaluate "$@";;
 --help|help) usage;;
 *) usage >&2; exit 2;;
esac
