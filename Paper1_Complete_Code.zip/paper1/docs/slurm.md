# VS Code and SLURM execution

Use VS Code Remote SSH on the host that mounts your data. Activate the existing environment; these scripts neither install dependencies nor fetch weights. Run heavy preparation, training and inference in an allocation according to cluster policy.

## Configuration and preparation

Edit `paper1/configs/project.json`: `datasets` supplies each dataset's canonical COCO `data` splits; `weights` supplies the five detector sizes/families; `enhancers` supplies local source/checkpoint adapters; `work_root` controls generated study outputs. Native preparation can be configured under each dataset's `prepare` object:

```bash
export PYTHONPATH="$PWD/paper1/src${PYTHONPATH:+:$PYTHONPATH}"
python -m lowlight_p1 prepare --config paper1/configs/project.json --dataset exdark
python -m lowlight_p1 doctor --config paper1/configs/project.json
python -m lowlight_p1 plan --config paper1/configs/project.json \
  --profile pilot --output /absolute/work/pilot.csv
```

Use the emitted resolved project configuration when preparation changes canonical paths. Inspect converter reports and official split assignments. `doctor` checks prerequisites; it is not detector/enhancer scientific qualification. Repeat GPU/import checks inside the intended allocation.

## Array submission

```bash
bash paper1/scripts/submit_array.sh \
  --manifest /absolute/work/pilot.csv --config paper1/configs/project.json \
  --partition YOUR_GPU_PARTITION --account YOUR_ACCOUNT \
  --gpus 1 --cpus 8 --memory 32G --time 12:00:00 \
  --max-concurrent 1 --output-root /absolute/work --dry-run
```

No partition/account is guessed; omit those options for scheduler defaults. Remove `--dry-run` to submit. A dry run validates merged configurations and prints a shell-escaped `sbatch` command without submitting or creating log directories. It does not load every image or validate learned checkpoint compatibility. Measure pilot throughput and peak memory before choosing full resources.

Array rows are zero-based CSV records excluding the header; quoted CSV fields are parsed properly. Do not reorder or edit a manifest during submission or retries. Generated rows refer to per-run configs. Keep those immutable too. Real submissions create `slurm_logs` before `sbatch`; `%A_%a` separates array/task logs. `--output-root` controls scheduler logs; project/run configurations control scientific outputs.

The default `--stage train` does not run test inference. `--stage predict` and `--stage evaluate` operate the run's configured inference view; `--stage run` explicitly requests combined training/prediction/evaluation and should not be used for test-driven recipe selection. For the complete required study view grid, run the dedicated evaluator inside a GPU allocation:

```bash
python -m lowlight_p1 study-evaluate --config paper1/configs/project.json \
  --manifest /absolute/work/pilot.csv --split dev
```

After freezing choices, repeat with `--split test`. Do not run this GPU operation directly on the login node.

## Activation, status and retries

For noninteractive jobs, supply `--activate-script /absolute/path/activate_myenv.sh`. The task sources this trusted file. Its content should activate your existing environment using the site's normal command; no activation is attempted when omitted. It must be a file you control.

```bash
python -m lowlight_p1 status --config paper1/configs/project.json \
  --manifest /absolute/work/pilot.csv
squeue -u "$USER"
# After inspecting and fixing an infrastructure failure, in a GPU allocation:
SLURM_ARRAY_TASK_ID=1 bash paper1/scripts/array_task.sh \
  /absolute/work/pilot.csv /absolute/path/project.json '' train
```

Keep the same manifest, code, data, checkpoints and scientific configuration when resuming. `resume: true` continues compatible checkpoints; changed scientific settings need a new run identity. Failed tasks remain failures. Do not replace a missing learned enhancer with gamma or replace unavailable P0 weights with dark-test training.

Plan `--profile full` only after the deciding pilot criterion in the audited specification. It contains 453 default-schedule trainings; diagnostic fits and inference perturbations are separate costs. Preserve pilot cells only when their exact provenance matches final cells.

```bash
bash paper1/tests/test_slurm.sh
```

These mocked wrapper checks cover quoting, stage forwarding, dry runs and submission arguments. They do not establish private-server availability or GPU success.
