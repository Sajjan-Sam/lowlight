# Stored predictions and representation analysis

The example configurations contain placeholder paths and category IDs. Their existence does not establish scientific qualification. First evaluate frozen checkpoints with the intended split and confirm prediction/checkpoint provenance. Never infer a view from its filename alone; inspect its provenance sidecar and run configuration.

## Prediction comparisons

Copy `paper1/configs/analysis.example.json` and replace every prediction filename with the actual hash-tagged artifact from the required run/view. Each condition's list must be ordered by the same training seeds, normally 0/1/2. Do not ensemble predictions or repeat one seed three times. Use one dataset, family and enhancer per initial comparison. Ground truth must be the identical evaluated split.

```bash
python -m lowlight_p1 analyze --config /absolute/work/exdark_sci_analysis.json
```

The example's four comparisons produce treatment minus baseline: RR−RE, EE−RE, RR−EE and EE−ER. Outputs include seed metrics, class/size/lighting tables, paired bootstrap draws, permutation comparisons with Holm correction, matched-object diagnostics and optional PNG/PDF figures. The default inference cap in the example is 100; use the actual predeclared cap consistently. AP values and contrasts use percentage points. A confidence shift is not per-object AP.

The `feature_pair` block is optional: remove it when descriptors have not been extracted. `mmd_bandwidth` is a predeclared feature-scale choice; the example value 1.0 is illustrative, not fitted evidence. Set `figures: false` for tables only when the existing environment lacks matplotlib. COCO metrics require the existing pycocotools runtime. No analysis command installs packages.

Set `cluster_key` to the exact ground-truth image metadata key for a known dependency unit when applicable. Do not treat repeated views or shared-image/model cells as independent samples. Lighting summaries use `images[].lighting` by default; change `lighting_key` to the actual metadata key. Absence of lighting metadata means no lighting-stratum evidence. A 0.5 AP50 equivalence claim additionally needs the declared interval/equivalence procedure on AP50; an ordinary AP comparison or non-significant p-value is insufficient.

## Paired feature extraction

Declare `feature_layers` in the scientific run config before planning/training. It is a list of exact detector `named_modules()` names, such as `backbone.body.layer2` and `backbone.fpn` for a compatible Faster R-CNN model. YOLO and RT-DETR names depend on the actual loaded architecture; inspect that model and select representative backbone and neck modules. Invalid names fail and report available names. Do not assume one family's names transfer to another.

Within an allocation, use the same saved training configuration/checkpoint for both views:

```bash
python -m lowlight_p1 features --config /absolute/work/full_configs/RUN.json \
  --split test --view raw
python -m lowlight_p1 features --config /absolute/work/full_configs/RUN.json \
  --split test --view enhanced \
  --enhancer-config '{"name":"sci","repo_path":"/absolute/SCI","weights_path":"/absolute/SCI.pth"}'
```

The backend stores image IDs, object IDs, category IDs, global pooled features and ground-truth ROI pooled descriptors in NPZ artifacts. Point `feature_pair.baseline` and `feature_pair.treatment` at those files. Analysis joins by explicit IDs and rejects unequal populations; it does not assume row ordering. Optionally choose one exact descriptor key with `feature_pair.key`, such as a saved key ending `/roi` or `/global`.

Linear CKA and RBF MMD are descriptive. Low similarity does not establish semantic information loss or causality. The built-in feature comparison does not establish held-out prediction of utility beyond brightness/class/size; that claim needs an explicitly fitted, independently evaluated model with dataset effects and dependency-aware uncertainty.

## Source-only P0

Copy `paper1/configs/p0.example.json`, use an existing released normal-light checkpoint and replace `source_category_map` with a verified mapping from the backend's emitted source label IDs to your COCO dataset category IDs. Its single `"1": 1` entry is a syntax example only; remove or replace it before scientific use. Torchvision uses COCO category labels; Ultralytics commonly emits zero-based contiguous class indices. Verify actual checkpoint label names and output indices rather than transferring numbers between backends. The target vocabulary must match canonical annotations. Report ExDark Table/Cup ambiguity and a sensitivity excluding ambiguous mappings.

```bash
python -m lowlight_p1 predict --config /absolute/work/p0_verified.json --split test --view raw
python -m lowlight_p1 evaluate --config /absolute/work/p0_verified.json --split test --view raw
```

Use `source_only: true` and prediction/evaluation commands only; training rejects source-only configurations. Unmapped source classes are omitted. A missing source checkpoint makes that P0 cell unavailable. DarkFace requires a separately labeled normal-light WIDER FACE checkpoint experiment; a COCO detector has no face class, so the three-family COCO P0 example is not a valid DarkFace substitute.

## Final refit and extra controls

After choosing recipes on development data, set project `final_refit: true` and provide each dataset's `train_all` canonical spec containing official training plus the held-out development subset. Native preparation emits this spec. Plan into a separate manifest/config directory and output root; preserve the development-selection runs. Final refit replaces training input with `train_all`; the development split remains recorded and overlaps that refit training population intentionally. Do not evaluate or select on development after refitting. Inspect generated configs and validate them before submission. Train with the frozen schedule, then explicitly run `study-evaluate --split test`. Test AP must not select checkpoints, strengths or schedules.

Optional `project.evaluation_controls` maps new control labels to complete enhancer specs. A label must have an operational meaning and its configuration/provenance must be frozen. For example:

```json
{
  "evaluation_controls": {
    "identity_roundtrip": {"name": "uint8", "reference_enhancer": {"name": "identity"}},
    "SCI_highfreq_sigma1": {"name": "high_frequency_swap", "sigma": 1, "reference_enhancer": {"name": "sci", "repo_path": "/absolute/SCI", "weights_path": "/absolute/SCI.pth"}}
  }
}
```

These controls add inference work to selected study evaluation, not new training cells. Include σ=4 as well as the σ=2 primary frequency construction when making sensitivity claims. Identity reconstruction, synthetic-noise/blur/chroma diagnostics, clipping rates and target-crop errors must be examined before interpreting component names physically. Frequency bands are not sensor noise.

A minimal frozen final sequence is:

```bash
python -m lowlight_p1 plan --config /absolute/work/final_project.json \
  --profile full --output /absolute/work/final/full.csv
bash paper1/scripts/submit_array.sh --config /absolute/work/final_project.json \
  --manifest /absolute/work/final/full.csv --output-root /absolute/work/final \
  --gpus 1 --cpus 8 --memory 32G --time 12:00:00 --dry-run
# Submit with measured site resources, wait for successful training, then in an allocation:
python -m lowlight_p1 study-evaluate --config /absolute/work/final_project.json \
  --manifest /absolute/work/final/full.csv --split test
python -m lowlight_p1 analyze --config /absolute/work/final_analysis.json
```

The resource values above are placeholders. No actual GPU runtime, external checkpoint loading or private dataset has been qualified by local tests. Store the allocation's measured timing/memory and calibration evidence alongside the outputs before claiming reproducibility.
