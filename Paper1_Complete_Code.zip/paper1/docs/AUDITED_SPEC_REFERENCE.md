# Paper 1 scientific specification

## 5. Paper 1: exact research question and protocol

Question: **How do labeled adaptation data, trainable capacity, training/test representation and enhancement type jointly determine detection utility?**

For each enhancer E complete the following matrix; the reverse-transfer cell costs inference only:

| Training | Raw test | Enhanced test |
|---|---|---|
| Raw | RR, source P1 | RE, source P2 |
| Enhanced | ER, previously missing | EE, source P3 |
| Raw/enhanced mixture | MR | ME, source P4 |

P0 uses a normal-light pretrained detector with no low-light training. COCO category mappings apply only where semantically valid. ExDark Table→dining table and Cup are approximate: report all mapped classes and a sensitivity excluding ambiguous classes. DarkFace has no COCO face class: use a released normal-light WIDER FACE detector as a separately labeled source-model experiment; do not pretend it is the same three-family P0 grid. If a verified source checkpoint is unavailable, mark that P0 cell unavailable instead of training on dark evaluation data.

Operational contrasts: deployment mismatch `RR−RE`; enhanced-domain adaptation gain `EE−RE`; matched-domain difference `RR−EE`; reverse transfer `EE−ER`. The first two sum algebraically with the matched-domain difference, but do not identify irrecoverable information destruction. Components can have either sign. Use actual AP alongside contrasts.

### Paper 1 full training matrix: 453 unique default-schedule jobs

All rows use seeds 0/1/2. Reuse a checkpoint only if image lists, views, optimizer schedule, initialization, seed and code hash match exactly.

| Group | Execute exactly | New trainings | Purpose |
|---|---|---:|---|
| P1-C | 3 datasets × YN/FR/RT × {raw, P3-SCI, P3-ZD, P3-RF, P3-PL, P4-SCI, P4-RF} × 3 seeds | 189 | Core protocol matrix; each checkpoint tested on raw and the required enhanced views. |
| P1-O | ExDark+DarkFace × YN × SCI/RF × {A(E(Gx)), E(A(Gx))} × 3 | 24 | Independent clean order experiment: matched G, no mosaic/mixup, a separate bank gamma {.8,1,1.25}. Both arms evaluated on identical deterministic E(Gx) and raw. |
| P1-A | ExDark+DarkFace × YN × {raw, P3-SCI, P3-RF} × 3 | 18 | Stronger-photometric sensitivity: use six photometric states {identity,gamma.7,gamma1.4,gamma.45,gamma2.0,noise-only} crossed with the two flips (12 exact views). Noise-only is clip(x+sqrt(.01*x+.0001)*epsilon,0,1), epsilon standard Normal generated from a saved per-image seed derived from image UID and global seed0; no gamma in that state; same total updates. |
| P1-Q | ExDark × YN × {P3-GS,P3-GR,P3-SCI-float,P3-RF-float} × 3 | 12 | Brightness and quantization controls. Identity round trip is evaluation-only unless it fails. |
| P1-K | ExDark × YS/YM × {raw,P3-SCI,P3-RF} × 3 | 18 | Capacity; selected full YM checkpoints can be reused as Paper 2 teachers. |
| P1-S | ExDark+DarkFace × YN × train fraction {.10,.25,.50} × {raw,P3-SCI,P3-RF} × 3 | 54 | Fine-tuned scaling, equal total optimizer updates to 100% baseline. Reuse full-data 100% core cells. |
| P1-F | Same two datasets × YN frozen backbone × fraction {.10,.25,.50,1} × 3 representations × 3 | 72 | Capacity/data interaction, equal updates. |
| P1-E | Same two datasets × YN fine-tuned × fraction {.10,.25,.50} × 3 representations × 3 | 54 | Equal-epoch sensitivity to distinguish data amount from optimization exposure. |
| P1-M | ExDark × YN × SCI/RF × {tone-only, high-frequency-swap} × 3 | 12 | Retraining sensitivity for two validated perturbations; full perturbation grid is inference-only. |
| **Total** | | **453** | Does not include short recipe fits, future extensions or failed infrastructure jobs. |

Nested scaling subsets use stratified class/brightness/object-size coverage, with subset seed paired to training seed (three jointly varied subset/training realizations, not a claim to separate their variance components). Each representation sees the identical subset. Equal-update means the count of optimizer steps, effective batch and LR progress are matched to the 100% run; additionally report repeat exposures per distinct image. Equal-epoch runs intentionally change total updates and are analyzed separately.

### Paper 1 evaluations and mechanism tests

Every core raw-trained checkpoint is evaluated on raw, SCI, ZD, RF, PL, GS and GR. Every P3 model is tested on raw and its matched enhancer; each P4 on raw and its matched enhancer. Every scaling/capacity run is evaluated on its training-matched representation and raw; raw scaling models additionally see SCI/RF. Reuse identical P2 inference outputs across analyses.

Full inference perturbation grid: two enhancers SCI/RF × three datasets × three raw-trained families × three seeds × six variants = 324 evaluations, plus identity and parent outputs already cached. Variants: tone-only; chroma swap at controlled luminance; low-frequency swap; high-frequency swap; leave-chroma-out; leave-high-frequency-out. Use raw-reference and full-enhancement anchors. Define luminance/chroma conversion and one fixed Gaussian lowpass (σ=2 pixels at model-input resolution), highpass `H(z)=z−L(z)`. Spatial-frequency bands are **not sensor noise**. Run σ∈{1,4} sensitivity at inference. Require identity/null swaps to reconstruct exactly before clipping; record clipping and target-box reconstruction error for hybrids. If component semantics fail on known synthetic examples, retain only descriptive frequency terminology. Do not promise an arbitrary 35-dB reconstruction criterion establishes physical correctness.

Exact hybrid definitions for the six variants: let x be preprocessed raw, y=E(x), t=global-gamma(x) matched to mean Y(y); Y=.299R+.587G+.114B on the stated sRGB tensor, C(z)=z/max(Y(z),1e−4), L a channelwise Gaussianσ2 with reflect boundary and kernel2ceil(3σ)+1, H=z−L(z). Tone=t; chroma=clip(Y(t)C(y)); lowfreq=clip(t+L(y)−L(t)); highfreq=clip(t+H(y)−H(t)); leave-chroma=clip(Y(y)C(t)); leave-highfreq=clip(y−H(y)+H(t)). These are operational image constructions. In particular, tone/chroma clipping and frequency swaps can alter other cues; their names do not assert isolated physical mechanisms. Check L(z)+H(z)=z before clipping and each self-swap identity, and report clipping afterward.

On a 100-image development diagnostic use separately injected known Poisson-Gaussian noise, blur and chroma changes to test which perturbation responds; include target crops and tiny objects. Do not fit filter parameters on test AP. Treat nonlinear clipping and cross-component interaction explicitly; no automatic causal Shapley interpretation.

TIDE: RR/RE/EE/ER for four enhancers, all families/datasets; detailed extraction on seed0 and aggregate AP contrasts on all seeds. Save Cls/Loc/Both/Dupe/Bkg/Miss. Matched outcomes: class-aware one-to-one assignment; recall at IoU .5/.75; IoU distribution of true matches; calibrated score shifts; false positives per image. Never call confidence change “per-object AP.”

Representation analysis: raw-trained neck levels and representative backbone stages; pair same images/objects; linear CKA, normalized ROI feature distance and MMD are descriptive. Predict held-out enhancer/family utility beyond brightness, pixel difference, class and size; do not report an apparent 100-cell correlation as 100 independent experiments. Fit dataset effects explicitly and cluster shared-image/model dependencies. Low CKA is not proof of lost semantic information.

Within each dataset report class, local target brightness, object size and lighting strata. Sony extreme tags are test-only metadata, never a training feature. DarkFace's predominately small faces motivate dataset-relative size bins in addition to original-coordinate COCO S/M/L.

### Paper 1 deciding pilot and publication condition

Start with ExDark+DarkFace, YN, raw/SCI/RF, one seed: six main checkpoints (subset of P1-C). Evaluate RR/RE/ER/EE/MR/ME where mixture models are available; add four P4 checkpoints for those two enhancers/datasets, giving ten pilot trainings. Then run the 10/25/100% scaling pilot for SCI and raw with equal updates on ExDark before broadening. Pilot jobs matching the manifest become reused final cells; otherwise record them as exploratory.

Proceed to 453 jobs only if at least one useful interaction remains after input/order/optimization controls: a reproducible change in enhancement utility with data or trainable capacity, or a perturbation that discriminates competing explanations beyond brightness alone. Predeclare .5 AP50 percentage points as a practical equivalence margin for the study. Non-significance is not equivalence: require the appropriate interval/equivalence procedure to lie within the margin before calling effects negligible. A meaningful null study can be publishable, but there is no guaranteed venue outcome.
