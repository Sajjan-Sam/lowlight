# Native dataset preparation

The converter never guesses an annotation format and never modifies source images.
The default dataset location is `/nfs/nas/samiran1/Sajjan/Dataset`; supply actual
image and annotation roots explicitly because archive layouts differ. Outputs go
to `/nfs/nas/samiran1/Sajjan/lowlight_paper1_runs/prepared/<dataset>/` by default.

Python API (stdlib and Pillow only; no dependency installation):

```python
from lowlight_p1.prepare import prepare
result = prepare({
    "dataset": "darkface",
    "image_root": "/nfs/nas/samiran1/Sajjan/Dataset/DarkFace/images",
    "annotation_root": "/nfs/nas/samiran1/Sajjan/Dataset/DarkFace/labels",
    "train_list": "/nfs/nas/samiran1/Sajjan/Dataset/DarkFace/train.txt",
    "test_list": "/nfs/nas/samiran1/Sajjan/Dataset/DarkFace/test.txt",
    "dev_fraction": 0.1,
    "seed": 0,
})
training_config["data"] = result["data"]
```

`prepare(config: dict) -> dict` returns `data` (train/dev/test annotation paths
and image roots), `train_all` (a separate annotation/image-root spec), and `manifest` (path). Common keys are `dataset`, `image_root`,
`annotation_root`, `output_root`, `dev_fraction`, and `seed`. `output_root` is the
parent of the dataset output directory. Input and output roots must be separate.

| Dataset value | Required native inputs | Coordinate convention |
| --- | --- | --- |
| `exdark` | `class_list`: official four-column filename/class/lighting/split list; bbGt labels under `annotation_root`, named `image.jpg.txt` | 1-based xywh; subtract one from x and y, preserve extents |
| `maet` | `train_list`, `test_list`: one image filename or extensionless ID per line; VOC XML under `annotation_root` | 1-based inclusive xyxy; subtract one from minima, extent = max − min + 1 |
| `darkface` | `train_list`, `test_list`; count-prefixed labels named `image.txt` | 0-based inclusive xyxy; extent = max − min + 1 |
| `nod` | `train_annotations`, `test_annotations`: existing COCO JSON; `image_root` | COCO 0-based xywh, unchanged |

Optional `bbox_convention` must equal respectively `xywh_1based`,
`xyxy_1based_inclusive`, `xyxy_0based_inclusive`, or `coco_xywh_0based`.
Different conventions require a separately audited adapter; coordinates are
never clipped or silently reinterpreted. DarkFace rows contain four coordinates
and optionally a binary ignore flag, preserved as COCO `iscrowd`.

ExDark official split values 1 and 2 form the training pool, while 3 remains
test; the official split, lighting value, and source class are saved per image.
The published validation partition is therefore pooled into the training pool
before deriving this experiment's internal development split. Label this protocol
explicitly in reports. MAET uses the supplied train/test lists. NOD retains category
IDs and all additional image metadata, including camera and lighting tags when
present; unavailable metadata is not inferred. MAET categories are sorted names;
ExDark uses the official twelve-class order; DarkFace has category `face`.
Do not merge category vocabularies between datasets.

The development partition is drawn only from the official training pool using
a deterministic seeded greedy iterative multilabel stratification: rare labels
are considered first, then images satisfy remaining class targets. It is an
approximation, not a guarantee of every class in both splits; singleton labels
cannot appear in both. The exact target count is rounded and bounded to keep at
least one train and one development image. The official test membership remains
untouched. All three outputs must be nonempty.

The converter rejects split overlap, byte-identical images across splits,
ambiguous basename fallback, traversal (including symlink escapes), reversed or
out-of-bounds boxes, mismatched VOC dimensions, and EXIF orientations other than
1. Explicit relative paths can distinguish duplicate basenames; basename-only
fallback must resolve uniquely. Images stay at native dimensions and on disk
under their original roots. COCO files are checked using the same `load_coco`
and `validate_data` functions used for training preflight.

`manifest.json` records input roots, source label/list hashes, image hashes,
output annotation hashes, category mappings, seed, development fraction,
coordinate conventions, and split counts. Preserve this manifest with each run.
The output JSON files retain per-image metadata, so class, lighting, and camera
analyses can use the original tags. Synthetic fixtures are used only by unit
tests; preparation requires real source files and never generates dataset data.

Run `validate-data` on the resulting training configuration before submitting
jobs. Test performance must never select enhancement strength or checkpoints.
Missing learned enhancement implementations or checkpoints remain blockers;
identity and gamma are diagnostic controls, not substitutes for learned methods.

`train_all.json` is the exact union of the prepared train and development images
and annotations, with unique regenerated IDs and unchanged boxes/categories. It
contains the entire native training pool and excludes every official test image.
Its spec appears under `result["train_all"]` and in the manifest, outside `data`,
because it intentionally overlaps train/dev. Use it only for final refitting
after model settings and training duration have been fixed using development
results. The manifest records its counts and annotation hash separately.
